from scenarios.base import Scenario, Choice
from services.game_engine import GameEngine
import random


async def ignore_scam(game):
    await GameEngine.update_stats(game, happiness=15)
    game["personality"]["saver"] += 2


async def fall_for_scam(game):
    await GameEngine.spend_money(game, 800)
    await GameEngine.update_stats(game, happiness=-40, health=-16)
    game["personality"]["risky"] += 3


async def buy_birthday(game):
    await GameEngine.spend_money(game, 600)
    await GameEngine.update_stats(game, happiness=30)
    game["personality"]["spender"] += 1


async def cheap_birthday(game):
    await GameEngine.spend_money(game, 200)
    await GameEngine.update_stats(game, happiness=10)
    game["personality"]["saver"] += 1


async def skip_birthday_gift(game):
    await GameEngine.update_stats(game, happiness=-20)
    game["personality"]["saver"] += 1


async def compare_prices(game):
    await GameEngine.spend_money(game, 300)  # нашёл дешевле
    await GameEngine.update_stats(game, happiness=20)
    game["personality"]["saver"] += 2


async def buy_first_shop(game):
    await GameEngine.spend_money(game, 550)  # дороже
    await GameEngine.update_stats(game, happiness=9)
    game["personality"]["spender"] += 1


async def invest_stocks(game):
    result = random.random()
    if result < 0.5:
        await GameEngine.add_money(game, 500)
        await GameEngine.update_stats(game, happiness=30)
    elif result < 0.8:
        pass  # ничего не изменилось
    else:
        await GameEngine.spend_money(game, 500)
        await GameEngine.update_stats(game, happiness=-26)
    game["personality"]["investor"] += 3


async def hold_cash(game):
    await GameEngine.add_goal_progress(game, 800)
    game["personality"]["saver"] += 1


async def extra_job_weekend(game):
    actual, mult = await GameEngine.add_money_earned(game, 1400)
    await GameEngine.update_stats(game, happiness=-10, health=-18)
    game["personality"]["saver"] += 2


async def rest_weekend(game):
    await GameEngine.update_stats(game, happiness=20, health=20)
    game["personality"]["spender"] += 1


async def check_budget(game):
    await GameEngine.update_stats(game, happiness=10)
    game["personality"]["saver"] += 3  # финансовая грамотность!


async def skip_budget(game):
    await GameEngine.update_stats(game, happiness=6)
    game["personality"]["spender"] += 1


async def donate_small(game):
    await GameEngine.spend_money(game, 100)
    await GameEngine.update_stats(game, happiness=19)


async def skip_donate(game):
    await GameEngine.update_stats(game, happiness=-6)
    game["personality"]["saver"] += 1


DAY4 = [
    Scenario(
        text=(
            "📅 День 4 — Четверг\n\n"
            "🚨 ВНИМАНИЕ! Мошенник!\n\n"
            "Тебе написал «незнакомец» в соц сети:\n"
            "«Привет! Я нашёл твой аккаунт в базе победителей. "
            "Ты выиграл 5 000 ₽! Перешли 800 ₽ для "
            "«подтверждения личности» — и получишь свой приз!»\n\n"
            "⚠️ Признаки мошенничества:\n"
            "• Требуют деньги для получения «выигрыша»\n"
            "• Незнакомый отправитель\n"
            "• Срочность и давление\n\n"
            "❗ Помни - никогда не доверяй подозрительным сообщениям и незнакомым людям!"
        ),
        allow_ai=True,
        choices=[
            Choice(
                text="❌ Игнорировать и заблокировать",
                action=ignore_scam,
                description="Правильное решение!",
            ),
            Choice(
                text="💸 Отправить деньги (−800 ₽)",
                action=fall_for_scam,
                description="Ты попал на мошенника...",
            ),
        ],
    ),
    Scenario(
        text=(
            "🎂 День рождения друга\n\n"
            "У лучшего друга завтра день рождения.\n"
            "Три варианта подарка:\n"
            "• Крутой подарок — 600 ₽\n"
            "• Скромный, но искренний — 200 ₽\n"
            "• Ничего не дарить\n\n"
            "💡 Дружба важна, но подарок по средствам "
            "тоже ценится."
        ),
        choices=[
            Choice(text="🎁 Крутой подарок (−600 ₽)", action=buy_birthday),
            Choice(text="💐 Скромный подарок (−200 ₽)", action=cheap_birthday),
            Choice(text="😶 Не дарить ничего", action=skip_birthday_gift),
        ],
    ),
    Scenario(
        text=(
            "🛒 Сравнение цен\n\n"
            "Тебе нужно купить рюкзак. В ближайшем магазине — 550 ₽.\n"
            "Можно потратить 20 минут и найти такой же на маркетплейсе "
            "за 300 ₽ с доставкой.\n\n"
            "💡 Сравнение цен перед покупкой — базовое правило "
            "финансовой грамотности. Экономия 250 ₽!"
        ),
        allow_ai=True,
        choices=[
            Choice(
                text="🔍 Сравнить и взять онлайн (−300 ₽)",
                action=compare_prices,
                description="Сэкономил 250 ₽!",
            ),
            Choice(text="🏪 Купить сразу здесь (−550 ₽)", action=buy_first_shop),
        ],
    ),
    Scenario(
        text=(
            "📊 Акции компании\n\n"
            "Папа предлагает помочь тебе купить акции "
            "известной компании на 500 ₽.\n\n"
            "🎲 Возможные исходы:\n"
            "• 50% — акции вырастут, получишь +500 ₽\n"
            "• 30% — ничего не изменится\n"
            "• 20% — акции упадут, потеряешь 500 ₽\n\n"
        ),
        allow_ai=True,
        choices=[
            Choice(text="📈 Купить акции (риск!)", action=invest_stocks),
            Choice(text="💰 Отложить в копилку", action=hold_cash),
        ],
    ),
    Scenario(
        text=(
            "📋 Ведение бюджета\n\n"
            "Учитель экономики задал задание: "
            "записать все свои траты за неделю.\n\n"
            "💡 Ведение личного бюджета — №1 навык "
            "финансовой грамотности. Когда видишь, куда уходят деньги, "
            "легче управлять ими.\n\n"
            "Сделаешь задание честно?"
        ),
        choices=[
            Choice(
                text="📝 Записать все траты",
                action=check_budget,
                description="Финансовая осознанность +3!",
            ),
            Choice(text="🙈 Пропустить задание", action=skip_budget),
        ],
    ),
    Scenario(
        text=(
            "❤️ Сбор на помощь животным\n\n"
            "В школе объявили сбор денег для приюта животных.\n"
            "Можно пожертвовать 100 ₽.\n\n"
            "💡 Благотворительность — часть финансовой культуры. "
            "Даже небольшая сумма помогает другим."
        ),
        choices=[
            Choice(
                text="❤️ Пожертвовать 100 ₽",
                action=donate_small,
                description="Доброе дело!",
            ),
            Choice(text="💰 Отложить на цель", action=skip_donate),
        ],
    ),
    Scenario(
        text=(
            "🌞 Подработка на выходных\n\n"
            "Знакомый предпринимателя предлагает "
            "помочь на ярмарке в субботу за 1400 ₽.\n\n"
            "Это займёт весь день. Или можно отдохнуть и "
            "восстановить здоровье и настроение."
        ),
        choices=[
            Choice(text="💼 Поработать (+1400 ₽)", action=extra_job_weekend),
            Choice(text="🏖️ Отдохнуть", action=rest_weekend),
        ],
    ),
]
