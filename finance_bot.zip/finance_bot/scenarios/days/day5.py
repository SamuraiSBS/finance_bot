from scenarios.base import Scenario, Choice
from services.game_engine import GameEngine
import random


async def buy_hype(game):
    await GameEngine.spend_money(game, 1200)
    await GameEngine.update_stats(game, happiness=30)
    game["personality"]["spender"] += 3


async def wait_sale(game):
    await GameEngine.update_stats(game, happiness=-10)
    game["personality"]["saver"] += 2


async def use_discount(game):
    await GameEngine.spend_money(game, 600)
    await GameEngine.update_stats(game, happiness=20)
    game["personality"]["saver"] += 2


async def trust_pyramid(game):
    await GameEngine.spend_money(game, 1000)
    await GameEngine.update_stats(game, happiness=-40, health=-15)
    game["personality"]["risky"] += 3


async def report_pyramid(game):
    await GameEngine.update_stats(game, happiness=15)
    game["personality"]["saver"] += 3


async def take_credit_phone(game):
    await GameEngine.add_money(game, 800)
    game["debt"] = game.get("debt", 0) + 1100  # 800 + проценты
    await GameEngine.update_stats(game, happiness=10)
    game["personality"]["risky"] += 2


async def save_for_phone(game):
    await GameEngine.add_goal_progress(game, 1000)
    game["personality"]["saver"] += 2


async def diversify_invest(game):
    # Распределённые инвестиции — более стабильный результат
    result = random.random()
    if result < 0.75:  # 75% шанс прибыли
        await GameEngine.add_money(game, 600)
        await GameEngine.update_stats(game, happiness=20)
    else:
        await GameEngine.spend_money(game, 200)
        await GameEngine.update_stats(game, happiness=-20)
    game["personality"]["investor"] += 3


async def one_stock(game):
    result = random.random()
    if result < 0.4:  # 40% шанс
        await GameEngine.add_money(game, 1000)
        await GameEngine.update_stats(game, happiness=30)
    else:
        await GameEngine.spend_money(game, 600)
        await GameEngine.update_stats(game, happiness=-29)
    game["personality"]["investor"] += 2
    game["personality"]["risky"] += 2


async def emergency_fund(game):
    await GameEngine.add_goal_progress(game, 600)
    await GameEngine.add_money(game, 200)
    await GameEngine.update_stats(game, happiness=10)
    game["personality"]["saver"] += 3


async def spend_windfall(game):
    await GameEngine.spend_money(game, 500)
    await GameEngine.update_stats(game, happiness=25)
    game["personality"]["spender"] += 2


async def buy_healthy_food(game):
    await GameEngine.spend_money(game, 250)
    await GameEngine.update_stats(game, health=40, hunger=30)


async def buy_junk_food(game):
    await GameEngine.spend_money(game, 150)
    await GameEngine.update_stats(game, happiness=30, health=-15, hunger=15)
    game["personality"]["spender"] += 1


async def cook_home(game):
    await GameEngine.update_stats(game, health=30, hunger=30, happiness=10)
    game["personality"]["saver"] += 1


DAY5 = [
    Scenario(
        text=(
            "📅 День 5 — Пятница\n\n"
            "🔥 Хайп-релиз!\n\n"
            "Вышли ОЧЕНЬ популярные кроссовки — "
            "ограниченная серия, 1 200 ₽.\n"
            "Все в классе хотят их. Продажи заканчиваются через 2 дня.\n\n"
            "Но через месяц будет распродажа — те же кроссовки "
            "за 600 ₽.\n\n"
            "💡 Маркетинг создаёт искусственную срочность, "
            "чтобы ты купил быстрее и дороже."
        ),
        allow_ai=True,
        choices=[
            Choice(text="🔥 Купить сейчас (−1200 ₽)", action=buy_hype),
            Choice(text="🏷️ Купить на распродаже (−600 ₽)", action=use_discount),
            Choice(text="❌ Не покупать", action=wait_sale),
        ],
    ),
    Scenario(
        text=(
            "🔺 Финансовая пирамида\n\n"
            "Старшеклассник зовёт в «проект»:\n"
            "«Вложи 1 000 ₽ — пригласи трёх друзей — "
            "получи 3 000 ₽! Я сам уже заработал!»\n\n"
            "⚠️ Признаки финансовой пирамиды:\n"
            "• Обещание лёгких денег\n"
            "• Нужно привлекать других\n"
            "• Нет реального продукта\n\n"
            "❗ Это незаконно и почти всегда заканчивается потерей денег."
        ),
        allow_ai=True,
        choices=[
            Choice(text="💸 Вложить 1 000 ₽", action=trust_pyramid),
            Choice(
                text="❌ Отказаться и предупредить друзей",
                action=report_pyramid,
                description="Правильно! Ты защитил себя и друзей",
            ),
        ],
    ),
    Scenario(
        text=(
            "📱 Кредит на телефон\n\n"
            "Твой старый телефон работает нормально.\n"
            "Магазин предлагает новый в кредит:\n"
            "«Возьми сейчас за 0 ₽! Плати по 550 ₽ в месяц × 2 месяца»\n\n"
            "⚠️ Итого отдашь 1 100 ₽ за телефон стоимостью 800 ₽.\n"
            "Переплата 300 ₽ — это цена «удобства».\n\n"
            "Нужен ли тебе новый телефон прямо сейчас?"
        ),
        allow_ai=True,
        choices=[
            Choice(text="📱 Взять в кредит", action=take_credit_phone),
            Choice(text="💰 Цель важнее", action=save_for_phone),
        ],
    ),
    Scenario(
        text=(
            "📊 Распределение (диверсификация) инвестиций\n\n"
            "У тебя есть 800 ₽ для инвестиций. Два варианта:\n\n"
            "🔵 Распределить по 3 разным компаниям\n"
            "→ 75% шанс заработать 600 ₽\n\n"
            "🔴 Всё в одну «горячую» акцию\n"
            "→ 40% шанс заработать 1 000 ₽\n"
            "→ 60% — потерять 600 ₽\n\n"
            "💡 «Не клади все яйца в одну корзину» — "
            "золотое правило инвестора."
        ),
        allow_ai=True,
        choices=[
            Choice(text="🔵 Распределить (75% успеха)", action=diversify_invest),
            Choice(text="🔴 Всё в одну (риск!)", action=one_stock),
        ],
    ),
    Scenario(
        text=(
            "🎁 Неожиданный доход\n\n"
            "Бабушка перевела 500 ₽ на карту как сюрприз!\n\n"
            "Что сделать с неожиданными деньгами?\n\n"
            "💡 Финансисты советуют:\n"
            "• Минимум 50% — в сбережения\n"
            "• Остаток — на своё усмотрение"
        ),
        choices=[
            Choice(
                text="🐷 Отложить в резервный фонд",
                action=emergency_fund,
                description="Умно! Резервный фонд защитит тебя",
            ),
            Choice(text="🛍️ Потратить с удовольствием", action=spend_windfall),
        ],
    ),
    Scenario(
        text=(
            "🥗 Что поесть?\n\n"
            "Время ужина. Три варианта:\n\n"
            "🥦 Здоровая еда из магазина — 200 ₽ - полезно для здоровья\n"
            "🍟 Фастфуд — 200 ₽ - вкусно, но вредно\n"
            "🍳 Приготовить дома — бесплатно\n\n"
            "💡 Готовка дома экономит деньги и здоровье."
        ),
        choices=[
            Choice(text="🥦 Здоровая еда (−250 ₽)", action=buy_healthy_food),
            Choice(text="🍟 Фастфуд (−150 ₽)", action=buy_junk_food),
            Choice(text="🍳 Приготовить дома (бесплатно)", action=cook_home),
        ],
    ),
]
