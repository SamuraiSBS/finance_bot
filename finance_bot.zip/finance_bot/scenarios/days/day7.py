from scenarios.base import Scenario, Choice
from services.game_engine import GameEngine
import random


async def full_summary(game):
    """Финальное подведение итогов — просто ачивка"""
    await GameEngine.update_stats(game, happiness=30)
    game["personality"]["saver"] += 5


async def final_invest_all(game):
    result = random.random()
    if result < 0.55:
        await GameEngine.add_money(game, game["money"] // 2)
        await GameEngine.update_stats(game, happiness=40)
    else:
        await GameEngine.spend_money(game, game["money"] // 3)
        await GameEngine.update_stats(game, happiness=-30)
    game["personality"]["investor"] += 3
    game["personality"]["risky"] += 2


async def final_save_all(game):
    remainder = game["goal"]["target"] - game["goal"]["current"]
    deposit = min(game["money"], remainder)
    await GameEngine.add_goal_progress(game, deposit)
    await GameEngine.spend_money(game, game["money"] // 2)
    await GameEngine.update_stats(game, happiness=30)
    game["personality"]["saver"] += 3


async def reflect_lessons(game):
    await GameEngine.update_stats(game, happiness=20, health=10)
    game["personality"]["saver"] += 3


async def plan_next_week(game):
    await GameEngine.update_stats(game, happiness=24)
    game["personality"]["saver"] += 4


async def live_moment(game):
    await GameEngine.spend_money(game, 300)
    await GameEngine.update_stats(game, happiness=30)
    game["personality"]["spender"] += 2


async def emergency_fund_final(game):
    deposit = game["money"] // 4
    await GameEngine.add_goal_progress(game, deposit)
    await GameEngine.update_stats(game, happiness=16)
    game["personality"]["saver"] += 3


async def spend_all_rest(game):
    await GameEngine.spend_money(game, game["money"] // 2)
    await GameEngine.update_stats(game, happiness=30)
    game["personality"]["spender"] += 3


async def final_charity(game):
    await GameEngine.spend_money(game, 200)
    await GameEngine.update_stats(game, happiness=30)


async def final_keep(game):
    await GameEngine.add_goal_progress(game, 400)
    game["personality"]["saver"] += 1


async def finish_game(game):
    """Финальная кнопка — ничего не меняет, просто завершает"""


DAY7 = [
    Scenario(
        text=(
            "📅 День 7 — Воскресенье. Последний день!\n\n"
            "🏆 Время подводить итоги\n\n"
            "За эту неделю ты:\n"
            "• Принимал решения о тратах и сбережениях\n"
            "• Встречался с мошенниками и пирамидами\n"
            "• Попробовал инвестировать\n"
            "• Узнал о кредитах и долгах\n\n"
            "Что для тебя было самым важным уроком?"
        ),
        choices=[
            Choice(
                text="💡 Важно всё обдумывать перед тратами", action=reflect_lessons
            ),
            Choice(text="📈 Инвестиции — путь к богатству", action=full_summary),
            Choice(text="🛡️ Защита от мошенников — главное", action=full_summary),
        ],
    ),
    Scenario(
        text=(
            "💰 Последний финансовый выбор недели\n\n"
            "У тебя ещё есть деньги. До цели осталось немного.\n\n"
            "Что сделаешь с оставшимися деньгами?"
        ),
        allow_ai=True,
        choices=[
            Choice(text="🎯 Вложить всё в цель!", action=final_save_all),
            Choice(text="📈 Последняя инвестиция (риск!)", action=final_invest_all),
            Choice(text="🎉 Потратить на себя", action=spend_all_rest),
        ],
    ),
    Scenario(
        text=(
            "📋 Планирование следующей недели\n\n"
            "Умный финансист всегда планирует наперёд.\n\n"
            "💡 Правило 50/30/20:\n"
            "• 50% — необходимые траты\n"
            "• 30% — желания и развлечения\n"
            "• 20% — сбережения\n\n"
            "Будешь планировать бюджет на следующую неделю?"
        ),
        choices=[
            Choice(
                text="📝 Составлю план бюджета",
                action=plan_next_week,
                description="Финансовая дисциплина!",
            ),
            Choice(text="🌊 Живу моментом!", action=live_moment),
        ],
    ),
    Scenario(
        text=(
            "🐷 Резервный фонд\n\n"
            "Финансисты советуют иметь «подушку безопасности» — "
            "деньги на 3–6 месяцев жизни на случай непредвиденного.\n\n"
            "Отложишь часть в резервный фонд "
            "или потратишь на удовольствия?"
        ),
        allow_ai=True,
        choices=[
            Choice(text="🐷 Отложить в резервный фонд", action=emergency_fund_final),
            Choice(text="🎉 Потратить — неделя прошла!", action=spend_all_rest),
        ],
    ),
    Scenario(
        text=(
            "❤️ Финальное доброе дело\n\n"
            "Последний день недели.\n"
            "В классе собирают на подарок учителю — 200 ₽.\n\n"
            "💡 Финансово грамотный человек умеет не только "
            "копить, но и делать добро в меру своих возможностей."
        ),
        choices=[
            Choice(text="❤️ Поучаствую (−200 ₽)", action=final_charity),
            Choice(text="💰 Добавлю к цели", action=final_keep),
        ],
    ),
    Scenario(
        text=(
            "🏁 Конец недели!\n\n"
            "Ты прошёл 7 дней симулятора финансовой жизни.\n\n"
            "Сейчас ИИ-аналитик изучит твои решения и "
            "подготовит персональный финансовый отчёт.\n\n"
            "🤖 Готов узнать, какой ты финансовый тип?"
        ),
        choices=[
            Choice(text="🎯 Получить финальный отчёт!", action=finish_game),
        ],
    ),
]
