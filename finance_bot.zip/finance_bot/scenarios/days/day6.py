from scenarios.base import Scenario, Choice
from services.game_engine import GameEngine
import random


async def no_debt(game):
    await GameEngine.add_goal_progress(game, 600)
    game["personality"]["saver"] += 1


async def start_small_business(game):
    result = random.random()
    if result < 0.7:
        await GameEngine.add_money(game, 900)
        await GameEngine.update_stats(game, happiness=30)
    else:
        await GameEngine.spend_money(game, 300)
        await GameEngine.update_stats(game, happiness=-16)
    game["personality"]["investor"] += 3


async def skip_business(game):
    await GameEngine.add_goal_progress(game, 800)
    game["personality"]["saver"] += 1


async def buy_insurance(game):
    await GameEngine.spend_money(game, 200)
    await GameEngine.update_stats(game, happiness=10, health=20)
    game["personality"]["saver"] += 2


async def skip_insurance(game):
    # без страховки — риск непредвиденных расходов
    if random.random() < 0.3:
        await GameEngine.spend_money(game, 800)
        await GameEngine.update_stats(game, happiness=-18, health=-30)
    game["personality"]["risky"] += 1


async def long_invest(game):
    # долгосрочные инвестиции — стабильнее
    await GameEngine.add_money(game, 400)
    await GameEngine.update_stats(game, happiness=15)
    game["personality"]["investor"] += 3


async def short_gamble(game):
    result = random.random()
    if result < 0.35:
        await GameEngine.add_money(game, 1200)
        await GameEngine.update_stats(game, happiness=30)
    else:
        await GameEngine.spend_money(game, 600)
        await GameEngine.update_stats(game, happiness=-20)
    game["personality"]["risky"] += 3


async def big_goal_push(game):
    await GameEngine.add_goal_progress(game, 1200)
    await GameEngine.update_stats(game, happiness=30)
    game["personality"]["saver"] += 3


async def relax_day(game):
    await GameEngine.update_stats(game, happiness=40, health=20)
    game["personality"]["spender"] += 1


async def tax_honest(game):
    await GameEngine.add_money(game, 1000)
    await GameEngine.spend_money(game, 130)  # 13% налог с 1000
    await GameEngine.update_stats(game, happiness=10)
    game["personality"]["saver"] += 2  # честность = ответственность


async def tax_skip(game):
    # маленький шанс «проверки»
    if random.random() < 0.99:
        await GameEngine.spend_money(game, 500)
        await GameEngine.update_stats(game, happiness=-30)
    else:
        await GameEngine.add_money(game, 1000)
        await GameEngine.update_stats(game, happiness=10)
    game["personality"]["risky"] += 2


async def share_knowledge(game):
    actual, mult = await GameEngine.add_money_earned(game, 400)
    await GameEngine.update_stats(game, happiness=20)
    game["personality"]["saver"] += 2


async def keep_secret(game):
    await GameEngine.update_stats(game, happiness=-10)


DAY6 = [
    Scenario(
        text=(
            "📅 День 6 — Суббота\n\n"
            "🏪 Своё дело\n\n"
            "Ты придумал идею: продавать домашнюю выпечку "
            "одноклассникам. Нужно вложить 300 ₽ на продукты.\n\n"
            "🎲 70% шанс заработать 900 ₽\n"
            "30% шанс потерять 300 ₽ (не купят)\n\n"
            "💡 Предпринимательство — это риск с расчётом.\n"
            "Начинать с малого — лучшая стратегия."
        ),
        allow_ai=True,
        choices=[
            Choice(text="🥐 Открыть мини-бизнес (−300 ₽)", action=start_small_business),
            Choice(text="💰 Лучше отложу деньги", action=skip_business),
        ],
    ),
    Scenario(
        text=(
            "🛡️ Страховка\n\n"
            "Мама предлагает оплатить страховку для твоего "
            "велосипеда за 200 ₽ на месяц.\n\n"
            "💡 Страхование — это защита от больших трат.\n"
            "Платишь немного сейчас → не платишь много потом.\n\n"
            "Без страховки: 30% шанс поломки на 800 ₽."
        ),
        allow_ai=True,
        choices=[
            Choice(
                text="🛡️ Застраховать (−200 ₽)",
                action=buy_insurance,
                description="Защита от рисков",
            ),
            Choice(text="🎲 Обойдусь", action=skip_insurance),
        ],
    ),
    Scenario(
        text=(
            "⏳ Время vs деньги\n\n"
            "Есть 1 000 ₽ для инвестиций. Два пути:\n\n"
            "🔵 Долгосрочный депозит — 100% гарантия +400 ₽ через год\n\n"
            "🔴 Криптовалюта — 35% шанс заработать 1 200 ₽ сейчас,\n"
            "65% шанс потерять 600 ₽\n\n"
            "💡 Сложные проценты работают на длинных дистанциях.\n"
            "Долгосрочные инвестиции почти всегда лучше ставок."
        ),
        allow_ai=True,
        choices=[
            Choice(text="🔵 Депозит (гарантия)", action=long_invest),
            Choice(text="🔴 Крипта (риск!)", action=short_gamble),
        ],
    ),
    Scenario(
        text=(
            "🏁 Финальный рывок к цели\n\n"
            "До конца недели остаётся 1 день.\n"
            "Можно сделать финальный рывок — поработать сегодня "
            "и отложить 1200 ₽ прямо к цели.\n\n"
            "Или устроить день отдыха — ты много работал!"
        ),
        allow_ai=True,
        choices=[
            Choice(text="💪 Финальный рывок (+1200 ₽ к цели)", action=big_goal_push),
            Choice(text="😴 День отдыха", action=relax_day),
        ],
    ),
    Scenario(
        text=(
            "📋 Налоги\n\n"
            "Ты заработал 1 000 ₽ подработкой.\n"
            "По закону нужно заплатить налог 13% = 130 ₽.\n\n"
            "💡 Налоги — это вклад в больницы, школы, дороги.\n"
            "Уклонение от налогов незаконно и аморально.\n\n"
            "Что выберешь?"
        ),
        choices=[
            Choice(
                text="✅ Заплатить налог (−130 ₽)",
                action=tax_honest,
                description="Честный гражданин!",
            ),
            Choice(
                text="🙈 Скрыть доход", action=tax_skip, description="Риск штрафа..."
            ),
        ],
    ),
    Scenario(
        text=(
            "📢 Поделиться знаниями\n\n"
            "Ты узнал много о финансах за эту неделю.\n"
            "Друг просит объяснить, как не попасться мошенникам.\n\n"
            "💡 Умение объяснять — тоже навык, который ценится!\n"
            "Некоторые люди платят за финансовые консультации."
        ),
        choices=[
            Choice(text="🤝 Рассказать другу (+400 ₽)", action=share_knowledge),
            Choice(text="🤷 Не хочу тратить время", action=keep_secret),
        ],
    ),
]
