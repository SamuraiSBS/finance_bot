from scenarios.base import Scenario, Choice
from services.game_engine import GameEngine
import random


async def do_part_time(game):
    actual, mult = await GameEngine.add_money_earned(game, 1000)
    await GameEngine.update_stats(game, happiness=-10, health=-6)
    game["personality"]["saver"] += 2


async def play_games(game):
    await GameEngine.update_stats(game, happiness=25)
    game["personality"]["spender"] += 1


async def open_piggy_bank(game):
    await GameEngine.add_goal_progress(game, game["money"] // 5)
    await GameEngine.update_stats(game, happiness=20)
    game["personality"]["saver"] += 2


async def keep_all(game):
    game["personality"]["spender"] += 1


async def buy_lunch_expensive(game):
    await GameEngine.spend_money(game, 350)
    await GameEngine.update_stats(game, hunger=30, happiness=15)
    game["personality"]["spender"] += 1


async def buy_lunch_cheap(game):
    await GameEngine.spend_money(game, 120)
    await GameEngine.update_stats(game, hunger=20, health=6)


async def bring_from_home(game):
    await GameEngine.update_stats(game, hunger=25, health=16, happiness=6)
    game["personality"]["saver"] += 1


async def buy_phone_case(game):
    await GameEngine.spend_money(game, 400)
    await GameEngine.update_stats(game, happiness=11)
    game["personality"]["spender"] += 1


async def skip_phone_case(game):
    await GameEngine.add_goal_progress(game, 800)
    game["personality"]["saver"] += 1


async def lend_money(game):
    # 70% вернут, 30% нет
    if random.random() < 0.7:
        await GameEngine.update_stats(game, happiness=10)
    else:
        await GameEngine.spend_money(game, 200)
        await GameEngine.update_stats(game, happiness=-30)
    game["personality"]["risky"] += 1


async def refuse_lend(game):
    await GameEngine.update_stats(game, happiness=-16)
    game["personality"]["saver"] += 1


async def buy_book(game):
    await GameEngine.spend_money(game, 250)
    await GameEngine.update_stats(game, happiness=16, health=10)
    game["personality"]["saver"] += 1  # вложение в знания — накопительский тип


async def skip_book(game):
    await GameEngine.add_goal_progress(game, 500)
    game["personality"]["saver"] += 1


async def subscribe_streaming(game):
    await GameEngine.spend_money(game, 299)
    await GameEngine.update_stats(game, happiness=20)
    game["personality"]["spender"] += 2


async def skip_streaming(game):
    await GameEngine.add_goal_progress(game, 600)
    await GameEngine.update_stats(game, happiness=-10)
    game["personality"]["saver"] += 1


DAY2 = [
    Scenario(
        text=(
            "📅 День 2 — Вторник\n\n"
            "У тебя есть несколько свободных часов после школы.\n"
            "Сосед-предприниматель предлагает помочь разложить "
            "товар на складе — заплатит 1000 ₽.\n\n"
            "Но ты устал, и хочется отдохнуть..."
        ),
        choices=[
            Choice(
                text="💼 Подработать (+1000 ₽)",
                action=do_part_time,
                description="Заработал, но устал",
            ),
            Choice(
                text="🎮 Поиграть дома",
                action=play_games,
                description="Отдохнул и поднял настроение",
            ),
        ],
    ),
    Scenario(
        text=(
            "🐷 Копилка\n\n"
            "Ты нашёл старую копилку — в ней 200 ₽ монетками.\n"
            "Можно добавить туда ещё пятую часть своих денег "
            "и создать отдельный фонд на крайний случай.\n\n"
            "Или оставить всё себе."
        ),
        choices=[
            Choice(
                text="🐷 Создать резервный фонд",
                action=open_piggy_bank,
                description="Умный финансовый шаг!",
            ),
            Choice(text="💸 Оставить всё при себе", action=keep_all),
        ],
    ),
    Scenario(
        text=(
            "🍕 Обед: что выбрать?\n\n"
            "Три варианта обеда:\n"
            "• Кафе — вкусно, 350 ₽\n"
            "• Столовая — нормально, 120 ₽\n"
            "• Еда из дома — вкусно, бесплатно\n\n"
        ),
        choices=[
            Choice(text="🍕 Кафе (−350 ₽)", action=buy_lunch_expensive),
            Choice(text="🥗 Столовая (−120 ₽)", action=buy_lunch_cheap),
            Choice(text="🥡 Еда из дома (бесплатно)", action=bring_from_home),
        ],
    ),
    Scenario(
        text=(
            "📱 Чехол на телефон\n\n"
            "В магазине видишь классный чехол за 400 ₽.\n"
            "Старый немного поцарапан, но телефон работает нормально.\n\n"
            "Нужно ли это прямо сейчас?"
        ),
        choices=[
            Choice(text="🛍️ Купить чехол (−400 ₽)", action=buy_phone_case),
            Choice(text="💰 Обойдусь, отложу", action=skip_phone_case),
        ],
    ),
    Scenario(
        text=(
            "🤝 Друг просит в долг\n\n"
            "Одноклассник просит 200 ₽ до пятницы — "
            "говорит, что точно вернёт.\n\n"
            "⚠️ Помни: деньги в долг — всегда риск. "
            "Не всегда возвращают вовремя (или вообще)."
        ),
        choices=[
            Choice(text="💸 Дать в долг", action=lend_money),
            Choice(text="❌ Отказать", action=refuse_lend),
        ],
    ),
    Scenario(
        text=(
            "📚 Книга по программированию\n\n"
            "В книжном магазине — интересная книга\n"
            "«Программируй и зарабатывай» за 250 ₽.\n\n"
            "Это вложение в знания, которые могут принести "
            "доход в будущем. Стоит ли покупать?"
        ),
        choices=[
            Choice(
                text="📗 Купить книгу (−250 ₽)",
                action=buy_book,
                description="Инвестиция в себя!",
            ),
            Choice(text="💰 Отложить деньги", action=skip_book),
        ],
    ),
    Scenario(
        text=(
            "🕹️ Подписка в онлайн-игре\n\n"
            "Твоя любимая онлайн-игра предлагает "
            "месячную подписку за 299 ₽,\n"
            "которая даёт доступ к уникальному контенту.\n\n"
            "💡 Подумай: сколько часов удовольствия за 299 ₽? "
            "Это оправданная трата?"
        ),
        choices=[
            Choice(text="🎵 Оформить подписку (−299 ₽)", action=subscribe_streaming),
            Choice(text="🔕 Обойтись без неё", action=skip_streaming),
        ],
    ),
]
