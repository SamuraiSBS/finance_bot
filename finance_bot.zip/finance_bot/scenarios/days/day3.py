from scenarios.base import Scenario, Choice
from services.game_engine import GameEngine
import random


async def sell_old_stuff(game):
    actual, mult = await GameEngine.add_money_earned(game, 1200)
    game["personality"]["saver"] += 2


async def keep_old_stuff(game):
    await GameEngine.update_stats(game, happiness=10)
    game["personality"]["spender"] += 1


async def take_loan(game):
    # берёт кредит — получает деньги но влезает в долг
    await GameEngine.add_money(game, 1000)
    game["debt"] = game.get("debt", 0) + 1200  # отдавать придётся больше
    await GameEngine.update_stats(game, happiness=10)
    game["personality"]["risky"] += 2


async def save_for_goal(game):
    await GameEngine.add_goal_progress(game, 800)
    game["personality"]["saver"] += 2


async def buy_trending(game):
    await GameEngine.spend_money(game, 700)
    await GameEngine.update_stats(game, happiness=25)
    game["personality"]["spender"] += 2


async def skip_trending(game):
    await GameEngine.update_stats(game, happiness=-9)
    game["personality"]["saver"] += 1


async def invest_small(game):
    result = random.random()
    if result < 0.6:
        await GameEngine.add_money(game, 360)
        await GameEngine.update_stats(game, happiness=24)
    else:
        await GameEngine.spend_money(game, 360)
        await GameEngine.update_stats(game, happiness=-26)
    game["personality"]["investor"] += 2


async def dont_invest(game):
    await GameEngine.add_goal_progress(game, 600)
    game["personality"]["saver"] += 1


async def fix_phone(game):
    await GameEngine.spend_money(game, 500)
    await GameEngine.update_stats(game, happiness=12, health=6)


async def ignore_phone(game):
    await GameEngine.update_stats(game, happiness=-10, health=-10)
    game["personality"]["risky"] += 1


async def buy_sport(game):
    await GameEngine.spend_money(game, 300)
    await GameEngine.update_stats(game, health=30, happiness=16)
    game["personality"]["saver"] += 1  # здоровье — инвестиция


async def skip_sport(game):
    await GameEngine.add_goal_progress(game, 600)
    await GameEngine.update_stats(game, health=-7, happiness=-8)
    game["personality"]["saver"] += 1


async def sell_handmade(game):
    actual, mult = await GameEngine.add_money_earned(game, 900)
    await GameEngine.update_stats(game, happiness=20)
    game["personality"]["saver"] += 2


async def skip_handmade(game):
    await GameEngine.update_stats(game, happiness=-10)
    game["personality"]["spender"] += 1


DAY3 = [
    Scenario(
        text=(
            "📅 День 3 — Среда\n\n"
            "Ты нашёл старые игрушки и книги, которые уже не нужны.\n"
            "Можно продать их за 1200 ₽.\n\n"
            "💡 Продажа ненужных вещей — отличный способ "
            "пополнить бюджет без лишних трат."
        ),
        choices=[
            Choice(text="📦 Продать старые вещи (+1200 ₽)", action=sell_old_stuff),
            Choice(text="🗃️ Оставить на память", action=keep_old_stuff),
        ],
    ),
    Scenario(
        text=(
            "👟 Новый тренд\n\n"
            "В магазине появились кроссовки, которые носят "
            "все топовые блогеры. Цена — 700 ₽.\n\n"
            "У тебя уже есть нормальные кроссовки.\n"
            "Это нужда или желание?\n\n"
            "💡 Нужда = то, без чего не обойтись.\n"
            "Желание = то, что хочется, но можно подождать."
        ),
        choices=[
            Choice(text="👟 Купить трендовые (−700 ₽)", action=buy_trending),
            Choice(text="✋ Обойдусь, у меня есть", action=skip_trending),
        ],
    ),
    Scenario(
        text=(
            "📈 Первые инвестиции\n\n"
            "Вы рассказываете однокласснику про приложение, "
            "где можно вложить 600 ₽ в акции компании.\n"
            "Шанс заработать +360 ₽ за неделю — 60%.\n"
            "Но есть и риск потерять 200 ₽.\n\n"
            "Ваш товарищ советует использовать нейросеть для помощи выбора и приобретения знаний об инвестициях."
        ),
        allow_ai=True,
        choices=[
            Choice(text="📈 Инвестировать 600 ₽ (риск!)", action=invest_small),
            Choice(text="💰 Отложить в копилку", action=dont_invest),
        ],
    ),
    Scenario(
        text=(
            "💳 Реклама микрозайма\n\n"
            "В телефоне выскочила реклама: "
            "«Получи 1 000 ₽ прямо сейчас! Отдай 1 200 ₽ через месяц»\n\n"
            "⚠️ Это кредит. Ты берёшь 1 000 ₽, "
            "но вернуть нужно 1 200 ₽ — это +20% переплата!\n\n"
            "Нужны ли тебе деньги прямо сейчас?"
        ),
        allow_ai=True,
        choices=[
            Choice(text="💸 Взять займ (+1000 ₽, долг −1200 ₽)", action=take_loan),
            Choice(text="❌ Отказаться от займа", action=save_for_goal),
        ],
    ),
    Scenario(
        text=(
            "📱 Экран телефона треснул\n\n"
            "Ты уронил телефон — появилась трещина на экране.\n"
            "Ремонт стоит 500 ₽. Телефон пока работает, "
            "но трещина может стать больше.\n\n"
            "Чинить сейчас или подождать?"
        ),
        allow_ai=True,
        choices=[
            Choice(text="🔧 Починить сейчас (−500 ₽)", action=fix_phone),
            Choice(text="⏳ Потерпеть, пока работает", action=ignore_phone),
        ],
    ),
    Scenario(
        text=(
            "⚽ Открылась спортивная секция \n\n"
            "В новом спорт-центре начался набор в команду по интересному тебе виду спорта.\n"
            "1 месяц занятий стоит 300 ₽.\n\n"
        ),
        allow_ai=True,
        choices=[
            Choice(
                text="🏃 Записаться в секцию (−300 ₽)",
                action=buy_sport,
                description="Здоровье +15!",
            ),
            Choice(text="💰 Отложить деньги", action=skip_sport),
        ],
    ),
    Scenario(
        text=(
            "🎨 Своё мини-дело\n\n"
            "Ты умеешь рисовать. Одноклассники предлагают "
            "заказать у тебя открытки на праздник — "
            "суммарно выйдет ~900 ₽.\n\n"
            "💡 Своё небольшое дело (самозанятость) — "
            "отличный способ зарабатывать на хобби!"
        ),
        allow_ai=True,
        choices=[
            Choice(text="🖌️ Нарисовать открытки (+900 ₽)", action=sell_handmade),
            Choice(text="😴 Не хочу тратить время", action=skip_handmade),
        ],
    ),
]
