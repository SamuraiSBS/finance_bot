from scenarios.base import Scenario, Choice
from services.game_engine import GameEngine


# ── actions ────────────────────────────────────────────────────────────────


async def buy_snack(game):
    await GameEngine.spend_money(game, 200)
    await GameEngine.update_stats(game, happiness=16, hunger=30)
    game["personality"]["spender"] += 1


async def save_snack(game):
    await GameEngine.add_goal_progress(game, 400)
    await GameEngine.update_stats(game, hunger=-20, happiness=-10)
    game["personality"]["saver"] += 1


async def walk_to_school(game):
    await GameEngine.update_stats(game, health=10, hunger=-16)
    game["personality"]["saver"] += 1


async def take_bus(game):
    await GameEngine.spend_money(game, 50)
    await GameEngine.update_stats(game, hunger=-2)


async def take_taxi(game):
    await GameEngine.spend_money(game, 300)
    await GameEngine.update_stats(game, happiness=10)
    game["personality"]["spender"] += 1


async def eat_canteen(game):
    await GameEngine.spend_money(game, 150)
    await GameEngine.update_stats(game, hunger=30, health=10)


async def skip_lunch(game):
    await GameEngine.update_stats(game, hunger=-30, happiness=-20)
    game["personality"]["saver"] += 1


async def help_neighbor(game):
    actual, mult = await GameEngine.add_money_earned(game, 600)
    await GameEngine.update_stats(game, happiness=15)
    game["personality"]["saver"] += 1


async def skip_neighbor(game):
    await GameEngine.update_stats(game, happiness=-10)
    game["personality"]["spender"] += 1


async def buy_game(game):
    await GameEngine.spend_money(game, 500)
    await GameEngine.update_stats(game, happiness=30)
    game["personality"]["spender"] += 2


async def save_game(game):
    await GameEngine.add_goal_progress(game, 1000)
    await GameEngine.update_stats(game, happiness=-10)
    game["personality"]["saver"] += 2


async def do_homework(game):
    await GameEngine.update_stats(game, happiness=-10, health=9)
    game["personality"]["saver"] += 1


async def watch_video(game):
    await GameEngine.update_stats(game, happiness=20, health=-9)
    game["personality"]["spender"] += 1


# ── scenarios ───────────────────────────────────────────────────────────────

DAY1 = [
    Scenario(
        text=(
            "📅 День 1 — Начало недели\n\n"
            "Ты получил 1 000 ₽ карманных денег на неделю.\n"
            "По дороге в школу проходишь мимо кафе — "
            "вкусно пахнет выпечкой. Перекус стоит 200 ₽.\n\n"
            "Ты копишь на цель, но и есть хочется.\n\nЧто сделаешь?"
        ),
        choices=[
            Choice(
                text="🥐 Купить перекус (−200 ₽)",
                action=buy_snack,
                description="Голод и счастье выросли",
            ),
            Choice(
                text="💰 Пропустить, отложить деньги",
                action=save_snack,
                description="Ближе к цели, но голоднее",
            ),
        ],
    ),
    Scenario(
        text=(
            "🚌 Как добраться до школы?\n\n"
            "Ты вышел чуть позже. Выбирай транспорт:\n"
            "• Пешком — бесплатно, но потеряешь силы\n"
            "• Автобус — 50 ₽, нормальный вариант\n"
            "• Такси — 300 ₽, быстро и комфортно"
        ),
        choices=[
            Choice(text="🚶 Пешком (бесплатно)", action=walk_to_school),
            Choice(text="🚌 Автобус (−50 ₽)", action=take_bus),
            Choice(text="🚕 Такси (−300 ₽)", action=take_taxi),
        ],
    ),
    Scenario(
        text=(
            "🍽️ Обед в столовой\n\n"
            "Время обеда. Поесть стоит 150 ₽.\n"
            "Можно потерпеть до дома — сэкономишь, "
            "но к вечеру будешь очень голодным."
        ),
        choices=[
            Choice(text="🥗 Пообедать (−150 ₽)", action=eat_canteen),
            Choice(text="⏭️ Потерпеть до дома", action=skip_lunch),
        ],
    ),
    Scenario(
        text=(
            "👴 Сосед просит о помощи\n\n"
            "По дороге домой пожилой сосед просит помочь донести продукты "
            "и предлагает заплатить 600 ₽."
        ),
        choices=[
            Choice(text="🤝 Помочь (+600 ₽)", action=help_neighbor),
            Choice(text="😴 Отдохнуть дома", action=skip_neighbor),
        ],
    ),
    Scenario(
        text=(
            "🎮 Друг зовёт в игру\n\n"
            "Друг скинул ссылку — новая онлайн-игра за 500 ₽. "
            "Говорит, очень крутая. Но ты уже тратил сегодня...\n\n"
            "Хочешь совет финансового консультанта? 🤖"
        ),
        choices=[
            Choice(text="🎮 Купить доступ (−500 ₽)", action=buy_game),
            Choice(text="❌ Отказаться, копить", action=save_game),
        ],
    ),
    Scenario(
        text=(
            "📚 Вечер: выбор досуга\n\n"
            "Дома два варианта:\n"
            "📖 Домашка — скучно, но полезно для здоровья и дисциплины\n"
            "📱 Видео до ночи — весело, но завтра будет тяжело\n\n"
            "💡 Финансово грамотный человек умеет жертвовать "
            "удовольствием ради будущего."
        ),
        choices=[
            Choice(text="📖 Сделать домашку", action=do_homework),
            Choice(text="📱 Смотреть видео", action=watch_video),
        ],
    ),
]
