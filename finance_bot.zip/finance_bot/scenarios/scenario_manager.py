from scenarios.week_scenario import SCENARIO

SCENARIOS = {
    1: SCENARIO
}