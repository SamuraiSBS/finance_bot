from dataclasses import dataclass
from typing import List, Callable, Awaitable


@dataclass
class Choice:

    text: str
    action: Callable[[dict], Awaitable[None]]
    description: str = ""


@dataclass
class Scenario:

    text: str
    choices: List[Choice]
    allow_ai: bool = False
