SCENARIO = {

    "start": {

        "text": "📅 День 1\nТы выходишь из дома. Как доберешься до школы?",

        "options": [

            {
                "text": "🚶 Пешком",
                "cost": 0,
                "comment": "Ты решил сэкономить деньги.",
                "next": "school_walk"
            },

            {
                "text": "🛴 Самокат",
                "cost": 150,
                "comment": "Быстро, но стоило денег.",
                "next": "school_scooter"
            },

            {
                "text": "🚌 Автобус",
                "cost": 50,
                "comment": "Обычный выбор.",
                "next": "school_bus"
            },

            {
                "text": "🚕 Такси",
                "cost": 300,
                "comment": "Очень дорого.",
                "next": "school_taxi"
            }
        ]
    },


    # если пешком
    "school_walk": {

        "text": "Ты пришел в школу пешком и проголодался. Что делать?",

        "options": [

            {
                "text": "Купить обед",
                "cost": 120,
                "comment": "Ты поел.",
                "next": "home_walk"
            },

            {
                "text": "Подождать",
                "cost": 0,
                "comment": "Ты решил потерпеть.",
                "next": "home_walk"
            }
        ]
    },


    # если самокат
    "school_scooter": {

        "text": "Самокат разрядился. Нужно решать дальше.",

        "options": [

            {
                "text": "Идти пешком",
                "cost": 0,
                "comment": "Ты пошел пешком.",
                "next": "home_walk"
            },

            {
                "text": "Вызвать такси",
                "cost": 300,
                "comment": "Снова дорого.",
                "next": "home_taxi"
            }
        ]
    },


    # если автобус
    "school_bus": {

        "text": "Ты приехал на автобусе. Что дальше?",

        "options": [

            {
                "text": "Купить еду",
                "cost": 120,
                "comment": "Хорошо.",
                "next": "home_bus"
            }
        ]
    },


    # если такси
    "school_taxi": {

        "text": "Ты потратил много денег. Будешь осторожнее?",

        "options": [

            {
                "text": "Да",
                "cost": 0,
                "comment": "Отлично.",
                "next": "home_walk"
            }
        ]
    },


    # домой пешком
    "home_walk": {

        "text": "Ты идешь домой пешком и видишь магазин.",

        "options": [

            {
                "text": "Купить игрушку",
                "cost": 500,
                "comment": "Дорого.",
                "next": None
            },

            {
                "text": "Не покупать",
                "cost": 0,
                "comment": "Отличный выбор.",
                "next": None
            }
        ]
    },


    "home_bus": {

        "text": "Ты едешь домой на автобусе.",

        "options": [

            {
                "text": "Доехать",
                "cost": 50,
                "comment": "Ты дома.",
                "next": None
            }
        ]
    },


    "home_taxi": {

        "text": "Ты доехал домой на такси.",

        "options": [

            {
                "text": "Зайти домой",
                "cost": 0,
                "comment": "Ты дома.",
                "next": None
            }
        ]
    }

}