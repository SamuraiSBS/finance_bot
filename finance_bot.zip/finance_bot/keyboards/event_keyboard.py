from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton


def event_keyboard(event):

    buttons = []

    for i, choice in enumerate(event["choices"]):

        buttons.append(
            [InlineKeyboardButton(text=choice["text"], callback_data=f"event:{i}")]
        )

    return InlineKeyboardMarkup(inline_keyboard=buttons)
