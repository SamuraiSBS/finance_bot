from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from scenarios.base import Scenario


def get_choices_keyboard(scenario: Scenario, question_index: int) -> InlineKeyboardMarkup:
    buttons = []

    for i, choice in enumerate(scenario.choices):
        buttons.append([
            InlineKeyboardButton(
                text=choice.text,
                callback_data=f"choice:{question_index}:{i}"
            )
        ])

    if scenario.allow_ai:
        buttons.append([
            InlineKeyboardButton(text="🤖 Спросить совет ИИ", callback_data=f"ask_ai:{question_index}")
        ])

    return InlineKeyboardMarkup(inline_keyboard=buttons)
