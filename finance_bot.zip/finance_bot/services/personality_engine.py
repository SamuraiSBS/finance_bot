from services.ai_engine import AIEngine


class PersonalityEngine:

    @staticmethod
    def calculate_type(game: dict) -> str:
        p = game.get("personality", {})
        if not p or all(v == 0 for v in p.values()):
            return "Сбалансированный"

        scores = {
            "Транжира 💸": p.get("spender", 0),
            "Накопитель 🐷": p.get("saver", 0),
            "Инвестор 📈": p.get("investor", 0),
            "Рискованный 🎲": p.get("risky", 0),
        }
        return max(scores, key=scores.get)

    @staticmethod
    async def get_full_analysis(game: dict):
        basic_type = PersonalityEngine.calculate_type(game)
        ai_analysis = await AIEngine.analyze_personality(game)
        return basic_type, ai_analysis
