from openai import AsyncOpenAI
from config import config
import json


client = AsyncOpenAI(
    api_key=config.OPENROUTER_API_KEY,
    base_url="https://openrouter.ai/api/v1",
)

MODEL = "deepseek/deepseek-chat"


class AIEventEngine:

    @staticmethod
    async def generate_event(game: dict):

        prompt = f"""
Придумай короткое событие для игры про финансовую грамотность подростка 12–15 лет.

Верни JSON строго такого формата:

{{
"text": "описание ситуации",
"choices": [
    {{
        "text": "вариант 1",
        "money": число,
        "happiness": число
    }},
    {{
        "text": "вариант 2",
        "money": число,
        "happiness": число
    }}
]
}}

Игрок:
Деньги: {game['money']}
"""

        response = await client.chat.completions.create(
            model=MODEL,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.9,
        )

        content = response.choices[0].message.content

        try:
            return json.loads(content)
        except Exception:
            return None
