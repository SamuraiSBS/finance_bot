from database.repositories import GameRepository, StatisticsRepository
from models.game_state import GameState
from services.stats_effects import earn_multiplier


class GameEngine:

    @staticmethod
    async def start_game(user_id: int):
        existing = await GameRepository.get_game(user_id)
        if existing:
            return existing
        game = GameState.create(user_id)
        await GameRepository.create_game(game)
        return game.to_dict()

    @staticmethod
    async def reset_game(user_id: int):
        await GameRepository.delete_active_game(user_id)

    @staticmethod
    async def add_money(game: dict, amount: int):
        game["money"] += amount

        await GameRepository.update_game(game["game_id"], {"money": game["money"]})

        if game["money"] <= 0:
            await GameEngine._kill(game, "money")

    @staticmethod
    async def add_money_earned(game: dict, base_amount: int):
        """
        Доход от подработки — применяет множитель характеристик.
        Показывает реальную сумму с пояснением если был штраф/бонус.
        """
        mult = earn_multiplier(game)
        actual = max(1, round(base_amount * mult))
        game["money"] += actual
        await GameRepository.update_game(game["game_id"], {"money": game["money"]})
        # Возвращаем инфу для отображения
        return actual, mult

    @staticmethod
    async def spend_money(game: dict, amount: int):
        game["money"] = max(0, game["money"] - amount)

        await GameRepository.update_game(game["game_id"], {"money": game["money"]})

        # ── GAME OVER при 0 денег ──
        if game["money"] <= 0:
            await GameEngine._kill(game, "money")

    @staticmethod
    async def add_goal_progress(game: dict, amount: int):
        game["goal"]["current"] = min(
            game["goal"]["current"] + amount, game["goal"]["target"]
        )
        await GameRepository.update_game(game["game_id"], {"goal": game["goal"]})

    @staticmethod
    async def next_day(game: dict):
        """Переход на следующий день + цепочки последствий."""
        from services.stats_effects import apply_daily_chains

        chain_msgs = await apply_daily_chains(game, GameEngine)

        game["day"] += 1
        game["question_index"] = 0

        # Небольшое ежедневное восстановление голода
        game["stats"]["hunger"] = min(100, game["stats"]["hunger"] + 8)

        await GameRepository.update_game(
            game["game_id"],
            {
                "day": game["day"],
                "question_index": 0,
                "stats": game["stats"],
                "money": game["money"],
            },
        )
        return chain_msgs

    @staticmethod
    async def update_stats(game: dict, happiness=0, health=0, hunger=0):
        s = game["stats"]
        s["happiness"] = max(0, min(100, s["happiness"] + happiness))
        s["health"] = max(0, min(100, s["health"] + health))
        s["hunger"] = max(0, min(100, s["hunger"] + hunger))

        # Мгновенный game over если любая характеристика = 0
        for key in ("health", "hunger", "happiness"):
            if s[key] <= 0:
                await GameEngine._kill(game, key)
                return False  # сигнал: игра завершена

        await GameRepository.update_game(game["game_id"], {"stats": s})
        return True  # всё ок

    @staticmethod
    async def _kill(game: dict, reason: str):
        game["is_dead"] = True
        game["is_finished"] = True
        await GameRepository.update_game(
            game["game_id"],
            {"is_dead": True, "is_finished": True, "stats": game["stats"]},
        )
        labels = {
            "health": "потеря здоровья",
            "hunger": "голод",
            "happiness": "потеря мотивации",
            "money": "банкротство",
        }
        await StatisticsRepository.save(
            game,
            f"💀 {labels.get(reason, reason)}",
            ai_report="Игра завершена досрочно — характеристики упали до нуля.",
        )

    @staticmethod
    async def finish(game: dict, result_type: str):
        await GameRepository.finish_game(game["game_id"])
