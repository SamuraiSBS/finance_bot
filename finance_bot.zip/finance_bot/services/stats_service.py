import json
import os

FILE = "data/users.json"


def load():

    if not os.path.exists(FILE):
        return {}

    with open(FILE, "r") as f:
        return json.load(f)


def save(data):

    with open(FILE, "w") as f:
        json.dump(data, f)


def register_user(user_id):

    data = load()

    if str(user_id) not in data:

        data[str(user_id)] = {
            "games_played": 0,
            "best_result": 0,
            "level": 1
        }

        save(data)


def add_game_result(user_id, money_left):

    data = load()

    user = data[str(user_id)]

    user["games_played"] += 1

    if money_left > user["best_result"]:
        user["best_result"] = money_left

    user["level"] = 1 + user["games_played"] // 3

    save(data)


def get_stats(user_id):

    data = load()

    user = data[str(user_id)]

    return (
        f"📊 Статистика\n\n"
        f"Уровень: {user['level']}\n"
        f"Игр сыграно: {user['games_played']}\n"
        f"Лучший результат: {user['best_result']}₽"
    )