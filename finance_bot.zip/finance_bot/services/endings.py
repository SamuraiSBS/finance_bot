"""
6 финалов игры — определяются по комбинации денег, цели и характеристик.
Каждый финал: уникальное название, эмодзи, описание, совет.
"""
from dataclasses import dataclass


@dataclass
class Ending:
    key: str
    title: str
    emoji: str
    description: str
    lesson: str
    score_bonus: int  # бонус к итоговому «счёту» для таблицы лидеров


ENDINGS: list[Ending] = [
    Ending(
        key="perfect",
        title="Идеальный баланс",
        emoji="🏆",
        description=(
            "Ты достиг цели И сохранил здоровье, сытость и счастье выше 70. "
            "Это высший пилотаж финансовой грамотности — ты понял, "
            "что деньги служат жизни, а не наоборот."
        ),
        lesson="Деньги — инструмент для счастливой жизни, а не самоцель.",
        score_bonus=500,
    ),
    Ending(
        key="goal_but_broken",
        title="Цель любой ценой",
        emoji="😰",
        description=(
            "Ты достиг финансовой цели, но ценой здоровья и счастья. "
            "В погоне за деньгами ты забыл о себе. "
            "Многие взрослые совершают ту же ошибку."
        ),
        lesson="Финансовый успех без здоровья и радости — пустая победа.",
        score_bonus=200,
    ),
    Ending(
        key="happy_poor",
        title="Счастливый без денег",
        emoji="😊",
        description=(
            "Ты не накопил на цель, но все характеристики выше 70 — "
            "ты здоров, сыт и доволен жизнью. "
            "Ты умеешь жить хорошо, но пора научиться и копить."
        ),
        lesson="Счастье важно, но финансовая подушка защищает от жизненных бурь.",
        score_bonus=150,
    ),
    Ending(
        key="survivor",
        title="Выживший",
        emoji="🛡️",
        description=(
            "Тяжёлая неделя. Ты не достиг цели, характеристики просели, "
            "но ты не сломался и дошёл до конца. "
            "Это уже победа — многие сдаются раньше."
        ),
        lesson="Финансовые трудности — это опыт. Главное — анализировать и расти.",
        score_bonus=50,
    ),
    Ending(
        key="debt_trap",
        title="В долговой яме",
        emoji="💳",
        description=(
            "Ты набрал долгов больше, чем заработал. "
            "Кредиты и займы без плана погашения — ловушка, "
            "из которой взрослые выбираются годами."
        ),
        lesson="Кредит — это аренда денег. Всегда считай полную стоимость долга.",
        score_bonus=0,
    ),
    Ending(
        key="game_over",
        title="Игра окончена",
        emoji="💀",
        description=(
            "Одна из характеристик упала до нуля. "
            "В реальной жизни всё взаимосвязано: "
            "если не следить за здоровьем, едой и настроением, "
            "финансовые решения становятся хуже."
        ),
        lesson="Финансовая грамотность начинается с заботы о себе.",
        score_bonus=0,
    ),
]


def determine_ending(game: dict) -> Ending:
    """Определяет финал по состоянию игры."""
    # Смерть — уже записана в game["is_dead"]
    if game.get("is_dead"):
        return _get("game_over")

    money   = game.get("money", 0)
    debt    = game.get("debt", 0)
    goal    = game.get("goal", {})
    s       = game.get("stats", {})

    goal_reached = goal.get("current", 0) >= goal.get("target", 1)
    health    = s.get("health", 100)
    hunger    = s.get("hunger", 100)
    happiness = s.get("happiness", 100)
    well_being = min(health, hunger, happiness)  # худшая характеристика

    # Долговая яма: долг > 50% от денег
    if debt > 0 and money > 0 and debt > money * 0.5:
        return _get("debt_trap")
    if debt > 0 and money == 0:
        return _get("debt_trap")

    if goal_reached:
        if well_being >= 70:
            return _get("perfect")
        else:
            return _get("goal_but_broken")
    else:
        if well_being >= 70:
            return _get("happy_poor")
        elif well_being >= 40:
            return _get("survivor")
        else:
            return _get("debt_trap")


def _get(key: str) -> Ending:
    return next(e for e in ENDINGS if e.key == key)


def format_ending(ending: Ending, game: dict) -> str:
    """Форматирует текст финального экрана."""
    goal = game.get("goal", {})
    pct = min(int(goal.get("current", 0) / max(goal.get("target", 1), 1) * 100), 100)
    debt = game.get("debt", 0)
    debt_str = f"\n💳 Долг: {debt} ₽" if debt > 0 else ""

    return (
        f"{ending.emoji} <b>{ending.title}</b>\n\n"
        f"{ending.description}\n\n"
        f"📊 <b>Итоги недели:</b>\n"
        f"💰 Деньги: {game.get('money', 0)} ₽{debt_str}\n"
        f"🎯 {goal.get('name', '?')}: {pct}% выполнено\n"
        f"❤️ {game['stats'].get('health', 0)}  "
        f"🍔 {game['stats'].get('hunger', 0)}  "
        f"😊 {game['stats'].get('happiness', 0)}\n\n"
        f"💡 <b>Главный урок:</b>\n{ending.lesson}"
    )
