from openai import AsyncOpenAI
from config import config
import re

client = AsyncOpenAI(
    api_key=config.OPENROUTER_API_KEY,
    base_url="https://openrouter.ai/api/v1",
)

MODEL = "deepseek/deepseek-chat"


def clean_ai_text(text: str) -> str:
    text = re.sub(r"\*\*(.*?)\*\*", r"\1", text)
    text = re.sub(r"\*(.*?)\*", r"\1", text)
    text = re.sub(r"^- ", "• ", text, flags=re.MULTILINE)
    text = re.sub(r"#{1,3}\s", "", text)
    return text.strip()


class AIEngine:

    @staticmethod
    async def get_advice(game: dict, situation: str) -> str:
        try:
            response = await client.chat.completions.create(
                model=MODEL,
                messages=[
                    {
                        "role": "system",
                        "content": (
                            "Ты финансовый советник для подростков 12–15 лет. "
                            "Отвечай коротко (2–3 предложения), понятно, без сложных терминов. "
                            "Не используй markdown-разметку."
                        ),
                    },
                    {
                        "role": "user",
                        "content": (
                            f"Ситуация: {situation}\n"
                            f"Деньги игрока: {game['money']} ₽\n"
                            f"Цель: {game['goal']['name']} ({game['goal']['current']}/{game['goal']['target']} ₽)\n"
                            f"Дай совет — что лучше выбрать и почему."
                        ),
                    },
                ],
                max_tokens=200,
                temperature=0.7,
            )
            return clean_ai_text(response.choices[0].message.content)
        except Exception as e:
            print("AI advice error:", e)
            return "💡 Совет: думай о долгосрочных последствиях каждого решения."

    @staticmethod
    async def analyze_personality(game: dict) -> str:
        p = game.get("personality", {})
        s = game.get("stats", {})
        goal = game.get("goal", {})

        try:
            response = await client.chat.completions.create(
                model=MODEL,
                messages=[
                    {
                        "role": "system",
                        "content": (
                            "Ты финансовый аналитик. Анализируешь поведение подростка "
                            "в финансовой игре. Пиши дружелюбно, ободряюще, "
                            "без markdown. Используй эмодзи умеренно."
                        ),
                    },
                    {
                        "role": "user",
                        "content": f"""
Статистика игрока:
• Транжира: {p.get('spender', 0)} очков
• Накопитель: {p.get('saver', 0)} очков  
• Инвестор: {p.get('investor', 0)} очков
• Рискованный: {p.get('risky', 0)} очков

Итоги недели:
• Деньги: {game.get('money', 0)} ₽
• Долг: {game.get('debt', 0)} ₽
• Цель "{goal.get('name', '?')}": {goal.get('current', 0)}/{goal.get('target', 0)} ₽
• Здоровье: {s.get('health', 0)}
• Счастье: {s.get('happiness', 0)}

Напиши персональный финансовый отчёт (4–6 предложений):
1. Какой финансовый тип у игрока и почему
2. Что он делал хорошо
3. Что стоит улучшить
4. Один конкретный совет на будущее
""",
                    },
                ],
                max_tokens=400,
                temperature=0.8,
            )
            return clean_ai_text(response.choices[0].message.content)
        except Exception as e:
            print("AI analysis error:", e)
            # Fallback без AI
            max_key = max(p, key=p.get) if p else "saver"
            labels = {
                "spender": "Транжира",
                "saver": "Накопитель",
                "investor": "Инвестор",
                "risky": "Рискованный",
            }
            t = labels.get(max_key, "Сбалансированный")
            return (
                f"Твой тип: {t}. "
                "Продолжай учиться управлять финансами — "
                "каждое правильное решение приближает тебя к своим целям!"
            )


    @staticmethod
    async def answer_question(question: str, game: dict = None) -> str:
        """Отвечает на произвольный финансовый вопрос пользователя."""
        context = ""
        if game:
            context = (
                f"\nКонтекст: игрок находится на дне {game.get('day', 1)}/7, "
                f"у него {game.get('money', 0)} ₽. "
                "Можешь привязать ответ к игровой ситуации если уместно.\n"
            )
        try:
            response = await client.chat.completions.create(
                model=MODEL,
                messages=[
                    {
                        "role": "system",
                        "content": (
                            "Ты финансовый помощник для подростков 12–15 лет. "
                            "Отвечай понятно, с примерами из жизни подростка, "
                            "без сложных терминов. Используй эмодзи умеренно. "
                            "Без markdown-разметки. Длина ответа — 3–5 предложений."
                            + context
                        ),
                    },
                    {"role": "user", "content": question},
                ],
                max_tokens=350,
                temperature=0.7,
            )
            return clean_ai_text(response.choices[0].message.content)
        except Exception as e:
            print("AI answer_question error:", e)
            return "🤖 Не смог получить ответ прямо сейчас. Попробуй чуть позже!"
