from scenarios.days.day1 import DAY1
from scenarios.days.day2 import DAY2
from scenarios.days.day3 import DAY3
from scenarios.days.day4 import DAY4
from scenarios.days.day5 import DAY5
from scenarios.days.day6 import DAY6
from scenarios.days.day7 import DAY7

DAY_SCENARIOS = {
    1: DAY1,
    2: DAY2,
    3: DAY3,
    4: DAY4,
    5: DAY5,
    6: DAY6,
    7: DAY7,
}


class ScenarioEngine:

    @staticmethod
    def get_current(game: dict):
        day = game.get("day", 1)
        q_index = game.get("question_index", 0)
        scenarios = DAY_SCENARIOS.get(day, [])

        if q_index >= len(scenarios):
            return None

        return scenarios[q_index]

    @staticmethod
    def total_for_day(day: int) -> int:
        return len(DAY_SCENARIOS.get(day, []))
