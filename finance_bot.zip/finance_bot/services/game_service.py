from scenarios.scenario_manager import SCENARIOS
from config import START_MONEY
from services.stats_service import add_game_result

users = {}


def start_game(user_id, scenario_id):

    users[user_id] = {
        "money": START_MONEY,
        "spent": 0,
        "node": SCENARIOS[scenario_id]["start"],
    }


def get_current_day(user_id):

    user = users[user_id]

    node = user["node"]

    if node is None:
        return None

    return node


def answer(user_id, text):

    user = users.get(user_id)

    if not user:
        return None

    current_node = user["node"]

    if current_node is None:
        return None

    options = current_node["options"]

    for option in options:

        if option["text"] == text:

            cost = option.get("cost", 0)

            user["money"] -= cost
            user["spent"] += cost

            comment = option.get("comment", "")

            next_key = option.get("next")

            if next_key:
                user["node"] = SCENARIOS[1][next_key]
            else:
                user["node"] = None

            return {"comment": comment}

    return None


def get_user_money(user_id):

    user = users.get(user_id)

    if not user:
        return 0

    return user["money"]
