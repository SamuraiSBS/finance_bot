"""
Система живых характеристик:
- Цепочки последствий между характеристиками
- Штрафы/бонусы к заработку
- Пороговые предупреждения
"""


# ── Пороги ──────────────────────────────────────────────────────────────────

CRITICAL   = 20   # 🔴 опасно
WARNING    = 40   # 🟡 плохо
GOOD       = 70   # 🟢 норма
BONUS      = 85   # ✨ бонус к заработку


# ── Коэффициент заработка от подработок ─────────────────────────────────────

def earn_multiplier(game: dict) -> float:
    """
    Возвращает множитель дохода от подработок.
    Здоровье < 40  → −30%
    Голод    < 30  → −20% (не можешь сосредоточиться)
    Счастье  < 30  → −15% (нет мотивации)
    Здоровье > 85 И счастье > 85 → +20% бонус
    """
    s = game.get("stats", {})
    health    = s.get("health", 100)
    hunger    = s.get("hunger", 100)
    happiness = s.get("happiness", 100)

    mult = 1.0

    if health < CRITICAL:
        mult -= 0.30
    elif health < WARNING:
        mult -= 0.15

    if hunger < CRITICAL:
        mult -= 0.20
    elif hunger < WARNING:
        mult -= 0.10

    if happiness < CRITICAL:
        mult -= 0.15
    elif happiness < WARNING:
        mult -= 0.08

    if health >= BONUS and happiness >= BONUS:
        mult += 0.20

    return max(0.2, round(mult, 2))  # минимум 20% от суммы


# ── Цепочки последствий — вызывается в начале каждого нового дня ─────────────

async def apply_daily_chains(game: dict, game_engine) -> list[str]:
    """
    Запускает цепочки последствий.
    Возвращает список текстовых уведомлений для игрока.
    """
    s = game["stats"]
    messages = []

    # ── Голод → Здоровье ──────────────────────────────────────────────────
    if s["hunger"] <= CRITICAL:
        penalty = 8
        s["health"] = max(0, s["health"] - penalty)
        messages.append(
            f"🍔➡️❤️ Ты почти не ел — здоровье упало на {penalty}!"
        )

    # ── Здоровье → Вынужденные расходы ───────────────────────────────────
    if s["health"] <= CRITICAL:
        import random
        cost = random.randint(200, 500)
        actual = min(cost, game["money"])
        game["money"] = max(0, game["money"] - actual)
        messages.append(
            f"❤️➡️💸 Ты заболел — пришлось потратить {actual} ₽ на лекарства!"
        )

    # ── Счастье → Импульсивные траты ──────────────────────────────────────
    if s["happiness"] <= CRITICAL:
        import random
        impulse = random.randint(100, 300)
        actual = min(impulse, game["money"])
        game["money"] = max(0, game["money"] - actual)
        messages.append(
            f"😢➡️💸 Тебе было очень плохо — ты потратил {actual} ₽ на импульсивную покупку чтобы поднять настроение..."
        )
        s["happiness"] = min(100, s["happiness"] + 15)

    # ── Голод → Счастье ───────────────────────────────────────────────────
    if s["hunger"] <= WARNING and s["happiness"] > CRITICAL:
        s["happiness"] = max(0, s["happiness"] - 5)
        messages.append("🍔➡️😊 Постоянный голод портит настроение (−5 счастья)")

    # Сохраняем обновлённые характеристики
    if messages:
        await game_engine.update_stats(game, 0, 0, 0)  # триггерит сохранение в БД
        # Обновляем деньги если были траты
        from database.repositories import GameRepository
        await GameRepository.update_game(
            game["game_id"],
            {"stats": game["stats"], "money": game["money"]}
        )

    return messages


# ── Предупреждения (показываются в статусе) ──────────────────────────────────

def get_warnings(game: dict) -> str:
    """Возвращает строку предупреждений для вставки под статус."""
    s = game.get("stats", {})
    warnings = []

    if s.get("hunger", 100) <= CRITICAL:
        warnings.append("⚠️ Критический голод! Срочно поешь — здоровье падает!")
    elif s.get("hunger", 100) <= WARNING:
        warnings.append("🍔 Ты голоден — заработок снижен на 10%")

    if s.get("health", 100) <= CRITICAL:
        warnings.append("⚠️ Критическое здоровье! Можешь заболеть и потерять деньги!")
    elif s.get("health", 100) <= WARNING:
        warnings.append("❤️ Здоровье слабое — заработок снижен на 15%")

    if s.get("happiness", 100) <= CRITICAL:
        warnings.append("⚠️ Ты в депрессии — риск импульсивных трат!")
    elif s.get("happiness", 100) <= WARNING:
        warnings.append("😔 Плохое настроение — заработок снижен на 8%")

    mult = earn_multiplier(game)
    if mult >= 1.20:
        warnings.append("✨ Ты в отличной форме — заработок +20%!")

    return "\n".join(warnings)
