from services.stats_effects import earn_multiplier


def format_status(game: dict) -> str:
    s    = game["stats"]
    g    = game["goal"]
    money = game["money"]
    debt  = game.get("debt", 0)
    progress_pct = min(int(g["current"] / g["target"] * 100), 100) if g["target"] > 0 else 0
    progress_bar = _bar(progress_pct)

    def _icon(val: int) -> str:
        if val >= 70: return "🟢"
        if val >= 40: return "🟡"
        return "🔴"

    mult = earn_multiplier(game)
    earn_str = ""
    if mult < 0.85:
        earn_str = f"  ⚡×{mult}"
    elif mult >= 1.15:
        earn_str = f"  ✨×{mult}"

    debt_str = f"  💳−{debt}₽" if debt > 0 else ""

    lines = [
        f"💰 {money}₽{debt_str}  |  📅 День {game['day']}/7{earn_str}",
        (
            f"❤️{_icon(s['health'])}{s['health']}  "
            f"🍔{_icon(s['hunger'])}{s['hunger']}  "
            f"😊{_icon(s['happiness'])}{s['happiness']}"
        ),
        f"🎯 {g['name']}: {progress_bar} {progress_pct}%",
        "─" * 30,
    ]
    return "\n".join(lines) + "\n"


def format_stat_delta(action_text: str, before: dict, after: dict, game: dict) -> str:
    """
    Формирует сообщение об изменении характеристик после выбора.
    Возвращает пустую строку если ничего не изменилось.
    """
    lines = []

    # Деньги
    dm = after["money"] - before["money"]
    if dm > 0:
        lines.append(f"💰 <b>+{dm} ₽</b>")
    elif dm < 0:
        lines.append(f"💰 <b>{dm} ₽</b>")

    # Цель (прогресс к накоплению)
    dg = after["goal"] - before["goal"]
    if dg > 0:
        lines.append(f"🎯 <b>+{dg} ₽</b> к цели")

    # Долг
    dd = after["debt"] - before["debt"]
    if dd > 0:
        lines.append(f"💳 Долг вырос на <b>+{dd} ₽</b>")
    elif dd < 0:
        lines.append(f"💳 Долг уменьшен на <b>{dd} ₽</b>")

    # Характеристики
    stat_map = [
        ("health",    "❤️ Здоровье"),
        ("hunger",    "🍔 Сытость"),
        ("happiness", "😊 Счастье"),
    ]
    for key, label in stat_map:
        delta = after[key] - before[key]
        if delta > 0:
            lines.append(f"{label} <b>+{delta}</b>")
        elif delta < 0:
            lines.append(f"{label} <b>{delta}</b>")

    if not lines:
        return ""

    changes = "  |  ".join(lines)
    # Берём первые несколько слов действия как заголовок
    short = action_text.split("(")[0].strip()[:40]
    return f"📋 <i>{short}</i>\n{changes}"


def _bar(pct: int, length: int = 10) -> str:
    filled = int(pct / 100 * length)
    return "█" * filled + "░" * (length - filled)
