from aiogram import Router, F
from aiogram.types import CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton, Message
import random

from services.game_engine import GameEngine
from database.repositories import GameRepository
from utils.formatters import format_status, format_stat_delta

router = Router()

# user_id → активное событие
ACTIVE_EVENTS: dict[int, dict] = {}
# user_id → (последний ключ события, счётчик подряд)
EVENT_HISTORY: dict[int, tuple[str, int]] = {}


RANDOM_EVENTS = [
    {
        "key": "sale",
        "text": (
            "🔔 <b>Распродажа!</b>\n\n"
            "В любимом магазине скидка 50% — только сегодня!\n"
            "Вещь стоит 600 ₽ вместо 1 200 ₽.\n\n"
            "💡 Скидка — экономия или повод потратить?"
        ),
        "choices": [
            {"text": "🛍️ Купить со скидкой", "money": -600, "happiness": 20, "label": "Купил со скидкой −600 ₽"},
            {"text": "❌ Не нужно, экономлю", "money": 0, "happiness": -5, "label": "Устоял перед скидкой"},
        ],
    },
    {
        "key": "lottery",
        "text": (
            "🎲 <b>Лотерейный билет!</b>\n\n"
            "Друг предлагает купить лотерейный билет за 100 ₽.\n\n"
            "⚠️ Вероятность выигрыша — меньше 1%.\n"
            "Лотерея — развлечение, а не способ заработать."
        ),
        "choices": [
            {"text": "🎫 Купить билет (−100 ₽)", "money": -100, "happiness": 12, "label": "Купил лотерейный билет −100 ₽"},
            {"text": "💰 Лучше отложу", "money": 100, "goal": 100, "happiness": 5, "label": "Отложил 100 ₽ вместо лотереи"},
        ],
    },
    {
        "key": "bike_broken",
        "text": (
            "🚲 <b>Сломался велосипед!</b>\n\n"
            "Колесо спустило — нужен ремонт 350 ₽.\n"
            "Или ходить пешком до конца недели.\n\n"
            "💡 Именно для таких случаев нужен резервный фонд!"
        ),
        "choices": [
            {"text": "🔧 Починить (−350 ₽)", "money": -350, "happiness": 15, "health": 8, "label": "Починил велосипед −350 ₽"},
            {"text": "🚶 Ходить пешком", "money": 0, "happiness": -15, "health": -8, "hunger": -10, "label": "Ходил пешком — здоровье −8"},
        ],
    },
    {
        "key": "uncle_gift",
        "text": (
            "📦 <b>Посылка от дяди!</b>\n\n"
            "Дядя перевёл 500 ₽ на карту — просто так!\n\n"
            "💡 Неожиданные доходы — отличный шанс пополнить сбережения."
        ),
        "choices": [
            {"text": "🐷 Отложить в копилку", "goal": 500, "happiness": 15, "label": "Отложил подарок +500 ₽ к цели"},
            {"text": "🛍️ Потратить с радостью", "money": 500, "label": "Получил +500 ₽ и потратил"},
        ],
    },
    {
        "key": "cold",
        "text": (
            "🤒 <b>Простудился!</b>\n\n"
            "Голова болит, температура. Лекарства — 250 ₽.\n"
            "Или попросить маму — бесплатно.\n\n"
            "💡 Здоровье — самый ценный ресурс."
        ),
        "choices": [
            {"text": "💊 Купить лекарства (−250 ₽)", "money": -250, "health": 30, "happiness": 10, "label": "Купил лекарства −250 ₽, здоровье +30"},
            {"text": "🤱 Попросить маму", "health": 20, "happiness": 5, "label": "Попросил маму, здоровье +20"},
        ],
    },
    {
        "key": "phishing",
        "text": (
            "📱 <b>Подозрительное сообщение!</b>\n\n"
            "СМС: «Ваша карта заблокирована! Срочно позвоните: 8-800-XXX»\n\n"
            "⚠️ Банки <b>никогда</b> не присылают такие СМС.\n"
            "Это фишинг — попытка украсть деньги."
        ),
        "choices": [
            {"text": "❌ Удалить и заблокировать", "happiness": 15, "label": "Распознал мошенника! Молодец!"},
            {"text": "📞 Позвонить «в банк»", "money": -600, "happiness": -30, "health": -10, "label": "Попался мошенникам −600 ₽"},
        ],
    },
    {
        "key": "game_skin",
        "text": (
            "🎮 <b>Редкий скин в игре!</b>\n\n"
            "Появился эксклюзивный скин за 450 ₽ — только 24 часа!\n\n"
            "💡 «Только сегодня» — маркетинговый трюк.\n"
            "Виртуальные вещи не имеют реальной ценности."
        ),
        "choices": [
            {"text": "🎨 Купить скин (−450 ₽)", "money": -450, "happiness": 20, "label": "Купил скин −450 ₽"},
            {"text": "💰 Реальные деньги важнее", "goal": 450, "happiness": -8, "label": "Устоял, отложил 450 ₽ к цели"},
        ],
    },
    {
        "key": "quick_job",
        "text": (
            "💼 <b>Быстрая подработка!</b>\n\n"
            "Знакомый предлагает помочь донести вещи —\n"
            "заплатит 450 ₽ прямо сейчас. Займёт 1 час."
        ),
        "choices": [
            {"text": "💪 Помочь (+450 ₽)", "money": 450, "happiness": 15, "hunger": -10, "label": "Подработал +450 ₽"},
            {"text": "😴 Отдохну лучше", "happiness": 15, "health": 8, "label": "Выбрал отдых"},
        ],
    },
    {
        "key": "found_money",
        "text": (
            "💵 <b>Нашёл деньги!</b>\n\n"
            "На улице лежат 200 ₽. Вокруг никого нет.\n\n"
            "💡 Честность — тоже финансовое качество."
        ),
        "choices": [
            {"text": "💰 Взять себе (+200 ₽)", "money": 200, "happiness": 10, "label": "Взял найденные деньги +200 ₽"},
            {"text": "🏛️ Отнести в полицию", "happiness": 20, "health": 5, "label": "Поступил честно"},
        ],
    },
    {
        "key": "stock_news",
        "text": (
            "📰 <b>Горячая новость!</b>\n\n"
            "В новостях пишут, что акции известной компании\n"
            "завтра должны вырасти на 30%.\n\n"
            "⚠️ Торговля на основе инсайда — незаконна.\n"
            "К тому же новость может быть ложной."
        ),
        "choices": [
            {"text": "📈 Вложить 500 ₽ (риск!)", "money": -500, "happiness": 5, "label": "Вложил 500 ₽ в акции по слухам"},
            {"text": "🚫 Не доверяю слухам", "goal": 300, "happiness": 8, "label": "Не поддался слухам, +300 ₽ к цели"},
        ],
    },
]


def _make_event_keyboard(event: dict, user_id: int) -> InlineKeyboardMarkup:
    buttons = [
        [InlineKeyboardButton(text=c["text"], callback_data=f"event:{user_id}:{i}")]
        for i, c in enumerate(event["choices"])
    ]
    return InlineKeyboardMarkup(inline_keyboard=buttons)


async def maybe_trigger_event(message: Message, game: dict) -> bool:
    """
    35% шанс случайного события.
    Ограничения:
    - не чаще раза в 3 вопроса
    - не повторять последнее событие
    - не более 2 подряд
    """
    q_index = game.get("question_index", 0)
    uid = game["user_id"]

    if q_index % 3 != 0 or q_index == 0:
        return False

    last_key, streak = EVENT_HISTORY.get(uid, ("", 0))
    if streak >= 2:
        EVENT_HISTORY[uid] = ("", 0)
        return False

    if random.random() > 0.35:
        EVENT_HISTORY[uid] = ("", 0)
        return False

    # Выбираем событие, исключая последнее
    pool = [e for e in RANDOM_EVENTS if e["key"] != last_key]
    event = random.choice(pool)

    EVENT_HISTORY[uid] = (event["key"], streak + 1)
    ACTIVE_EVENTS[uid] = event

    status = format_status(game)
    await message.answer(
        f"{status}🎲 <b>Случайное событие!</b>\n\n{event['text']}",
        reply_markup=_make_event_keyboard(event, uid),
        parse_mode="HTML",
    )
    return True


@router.callback_query(F.data.startswith("event:"))
async def handle_event(callback: CallbackQuery):
    parts = callback.data.split(":")
    user_id     = int(parts[1])
    choice_idx  = int(parts[2])

    event = ACTIVE_EVENTS.get(user_id)
    if not event:
        await callback.answer("Событие устарело.", show_alert=True)
        return

    choice = event["choices"][choice_idx]
    game   = await GameRepository.get_game(user_id)
    if not game:
        await callback.answer()
        return

    # Снэпшот до
    from handlers.game import _snap_stats
    before = _snap_stats(game)

    # Применяем эффекты
    money_delta = choice.get("money", 0)
    if money_delta > 0:
        await GameEngine.add_money(game, money_delta)
    elif money_delta < 0:
        await GameEngine.spend_money(game, abs(money_delta))

    if choice.get("goal", 0) > 0:
        await GameEngine.add_goal_progress(game, choice["goal"])

    await GameEngine.update_stats(
        game,
        happiness=choice.get("happiness", 0),
        health=choice.get("health", 0),
        hunger=choice.get("hunger", 0),
    )

    del ACTIVE_EVENTS[user_id]
    await callback.answer(f"✓ {choice.get('label', 'Готово')}")

    # Снэпшот после + дельта-сообщение
    game_fresh = await GameRepository.get_game(user_id)
    if game_fresh:
        after = _snap_stats(game_fresh)
        delta_text = format_stat_delta(choice.get("label", event["key"]), before, after, game_fresh)
        if delta_text:
            await callback.message.answer(delta_text, parse_mode="HTML")

        from handlers.game import send_current_scenario
        await send_current_scenario(callback.message, game_fresh)
