from aiogram import Router, F
from aiogram.types import CallbackQuery, Message, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup

from database.repositories import GameRepository
from services.ai_engine import AIEngine
from services.scenario_engine import ScenarioEngine
from config import config

router = Router()

# Имя модели для отображения пользователю
AI_MODEL_DISPLAY = "DeepSeek Chat"

# Готовые вопросы по темам
PRESET_QUESTIONS = [
    ("💰 Что такое бюджет?",           "Что такое личный бюджет и зачем его вести?"),
    ("📈 Как работают инвестиции?",    "Как работают инвестиции? Объясни просто для подростка."),
    ("🏦 Зачем нужен банк?",           "Зачем нужен банк и как он зарабатывает деньги?"),
    ("💳 Что такое кредит?",           "Что такое кредит и когда его стоит брать?"),
    ("🎲 Что такое финансовая пирамида?", "Что такое финансовая пирамида и почему это опасно?"),
    ("📊 Как начать копить?",          "Как подростку начать копить деньги? Простые советы."),
    ("🛡️ Как не попасться мошенникам?", "Какие признаки финансового мошенничества? Как защититься?"),
    ("🤔 Нужды vs желания",            "Объясни разницу между нуждами и желаниями в финансах."),
]


class AIState(StatesGroup):
    waiting_for_question = State()


# ── Кнопка «Спросить ИИ» в сценарии ─────────────────────────────────────────

@router.callback_query(F.data.startswith("ask_ai:"))
async def ask_ai_menu(callback: CallbackQuery):
    await callback.answer()

    buttons = []
    for i, (label, _) in enumerate(PRESET_QUESTIONS):
        buttons.append([
            InlineKeyboardButton(text=label, callback_data=f"ai_q:{i}")
        ])
    buttons.append([
        InlineKeyboardButton(text="✏️ Задать свой вопрос", callback_data="ai_q:custom")
    ])
    buttons.append([
        InlineKeyboardButton(text="▶️ Вернуться к игре", callback_data="ai_q:back")
    ])

    q_index = callback.data.split(":")[1]
    await callback.message.answer(
        f"🤖 Привет! Я искусственный интеллект <b>{AI_MODEL_DISPLAY}</b>.\n\n"
        "Ты можешь задать мне любой вопрос о финансах, деньгах или экономике!\n\n"
        "Выбери вопрос или задай свой:",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=buttons),
    )


# ── Готовый вопрос ────────────────────────────────────────────────────────────

@router.callback_query(F.data.startswith("ai_q:"))
async def handle_ai_question(callback: CallbackQuery, state: FSMContext):
    action = callback.data.split(":", 1)[1]

    if action == "back":
        await callback.answer()
        uid = callback.from_user.id
        game = await GameRepository.get_game(uid)
        if game:
            from handlers.game import send_current_scenario
            await send_current_scenario(callback.message, game)
        return

    if action == "custom":
        await callback.answer()
        await state.set_state(AIState.waiting_for_question)
        keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="❌ Отмена", callback_data="ai_q:back")]
        ])
        await callback.message.answer(
            "✏️ Напиши свой вопрос — я отвечу!\n\n"
            "<i>(Можно спросить что угодно о деньгах, инвестициях, экономике)</i>",
            parse_mode="HTML",
            reply_markup=keyboard,
        )
        return

    # Готовый вопрос по индексу
    try:
        idx = int(action)
    except ValueError:
        await callback.answer()
        return

    label, question = PRESET_QUESTIONS[idx]
    await callback.answer(f"🤔 Думаю над ответом...")

    game = await GameRepository.get_game(callback.from_user.id)
    answer = await AIEngine.answer_question(question, game)

    back_keyboard = _back_to_game_keyboard()
    await callback.message.answer(
        f"🤖 <b>{label}</b>\n\n{answer}",
        parse_mode="HTML",
        reply_markup=back_keyboard,
    )


# ── Свой вопрос пользователя ─────────────────────────────────────────────────

@router.message(AIState.waiting_for_question)
async def handle_custom_question(message: Message, state: FSMContext):
    await state.clear()

    question = message.text.strip()
    if not question:
        await message.answer("Вопрос пустой. Попробуй ещё раз.")
        return

    thinking = await message.answer("🤖 Думаю...")

    game = await GameRepository.get_game(message.from_user.id)
    answer = await AIEngine.answer_question(question, game)

    await thinking.delete()
    await message.answer(
        f"🤖 <b>Твой вопрос:</b> {question}\n\n{answer}",
        parse_mode="HTML",
        reply_markup=_back_to_game_keyboard(),
    )


def _back_to_game_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔙 Ещё вопрос", callback_data="ai_q:menu")],
        [InlineKeyboardButton(text="▶️ Вернуться к игре", callback_data="ai_q:back")],
    ])


@router.callback_query(F.data == "ai_q:menu")
async def ai_back_to_menu(callback: CallbackQuery):
    await callback.answer()
    buttons = []
    for i, (label, _) in enumerate(PRESET_QUESTIONS):
        buttons.append([
            InlineKeyboardButton(text=label, callback_data=f"ai_q:{i}")
        ])
    buttons.append([InlineKeyboardButton(text="✏️ Задать свой вопрос", callback_data="ai_q:custom")])
    buttons.append([InlineKeyboardButton(text="▶️ Вернуться к игре", callback_data="ai_q:back")])

    await callback.message.answer(
        f"🤖 <b>{AI_MODEL_DISPLAY}</b> — задай ещё вопрос:",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=buttons),
    )
