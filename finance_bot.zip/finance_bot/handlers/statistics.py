from aiogram import Router, F
from aiogram.types import CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from database.repositories import StatisticsRepository

router = Router()


@router.callback_query(F.data.startswith("stat:"))
async def stat_detail(callback: CallbackQuery):
    await callback.answer()
    game_id = callback.data.split(":", 1)[1]

    stats = await StatisticsRepository.get_by_game_id(game_id)
    if not stats:
        await callback.message.answer("Результат не найден.")
        return

    date = stats.get("created_at")
    date_str = date.strftime("%d.%m.%Y %H:%M") if date else "—"
    goal_ok = "✅ Да" if stats.get("goal_completed") else "❌ Нет"
    death = "💀 Да" if stats.get("is_dead") else "✅ Нет"

    p = stats.get("personality", {})
    personality_lines = (
        f"💸 Транжира: {p.get('spender', 0)}\n"
        f"🐷 Накопитель: {p.get('saver', 0)}\n"
        f"📈 Инвестор: {p.get('investor', 0)}\n"
        f"🎲 Рискованный: {p.get('risky', 0)}"
    )

    final_stats = stats.get("final_stats", {})
    stats_lines = (
        f"❤️ Здоровье: {final_stats.get('health', '?')}\n"
        f"🍔 Голод: {final_stats.get('hunger', '?')}\n"
        f"😊 Счастье: {final_stats.get('happiness', '?')}"
    )

    ai_report = stats.get("ai_report", "Отчёт недоступен.")

    text = (
        f"📊 <b>Результат игры</b>\n"
        f"📅 {date_str}\n\n"
        f"🧠 <b>Тип: {stats.get('result_type', '?')}</b>\n"
        f"💰 Деньги: {stats.get('final_money', 0)} ₽\n"
        f"💳 Долг: {stats.get('final_debt', 0)} ₽\n"
        f"📅 Дней пройдено: {stats.get('days_completed', 0)}\n"
        f"🎯 Цель достигнута: {goal_ok}\n"
        f"💀 Погиб: {death}\n\n"
        f"<b>📈 Профиль поведения:</b>\n{personality_lines}\n\n"
        f"<b>❤️ Финальные характеристики:</b>\n{stats_lines}\n\n"
        f"<b>🤖 Отчёт ИИ-аналитика:</b>\n{ai_report}"
    )

    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="◀️ Назад к списку", callback_data="menu:results")],
        [InlineKeyboardButton(text="🔄 Сыграть снова", callback_data="game:restart")],
    ])

    await callback.message.answer(text, parse_mode="HTML", reply_markup=keyboard)
