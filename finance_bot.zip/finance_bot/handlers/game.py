from aiogram import Router, F
from aiogram.types import (
    Message,
    CallbackQuery,
    InlineKeyboardMarkup,
    InlineKeyboardButton,
)

from services.game_engine import GameEngine
from database.repositories import GameRepository
from services.scenario_engine import ScenarioEngine
from keyboards.game_keyboard import get_choices_keyboard
from handlers.events import maybe_trigger_event
from utils.formatters import format_status, format_stat_delta
from services.stats_effects import get_warnings

router = Router()


async def start_game_handler(message: Message, user_id: int = None):
    uid = user_id or message.from_user.id
    game = await GameEngine.start_game(uid)
    await send_current_scenario(message, game)


# ── Продолжить / Новая игра ──────────────────────────────────────────────────


@router.callback_query(F.data == "game:continue")
async def continue_game(callback: CallbackQuery):
    await callback.answer()
    game = await GameRepository.get_game(callback.from_user.id)
    if not game:
        await start_game_handler(callback.message, callback.from_user.id)
        return
    await send_current_scenario(callback.message, game)


@router.callback_query(F.data == "game:confirm_new")
async def confirm_new_game(callback: CallbackQuery):
    await callback.answer()
    keyboard = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="✅ Да, начать заново", callback_data="game:restart"
                )
            ],
            [
                InlineKeyboardButton(
                    text="◀️ Нет, продолжить", callback_data="game:continue"
                )
            ],
        ]
    )
    await callback.message.answer(
        "⚠️ <b>Уверен?</b>\n\nВесь текущий прогресс будет потерян.",
        parse_mode="HTML",
        reply_markup=keyboard,
    )


@router.callback_query(F.data == "game:restart")
async def restart_game(callback: CallbackQuery):
    await callback.answer()
    await GameEngine.reset_game(callback.from_user.id)
    game = await GameEngine.start_game(callback.from_user.id)
    await send_current_scenario(callback.message, game)


# ── Основной поток ───────────────────────────────────────────────────────────


async def send_current_scenario(message: Message, game: dict):
    if game.get("is_dead") or game.get("is_finished"):
        await finish_game(message, game)
        return

    scenario = ScenarioEngine.get_current(game)

    if not scenario:
        if game["day"] >= 7:
            await finish_game(message, game)
            return

        chain_msgs = await GameEngine.next_day(game)
        game = await GameRepository.get_game(game["user_id"])
        scenario = ScenarioEngine.get_current(game)

        if game.get("is_dead"):
            await finish_game(message, game)
            return

        status = format_status(game)
        chain_block = ""
        if chain_msgs:
            chain_block = "\n\n🔗 <b>Последствия вчерашних решений:</b>\n" + "\n".join(
                chain_msgs
            )

        day_text = (
            f"{status}✅ <b>День {game['day'] - 1} завершён!</b>{chain_block}\n\n"
            f"📅 <b>Начинается день {game['day']}...</b>"
        )

        # ── Картинка нового дня (у каждого дня своя) ──
        import os
        from aiogram.types import FSInputFile

        day_number = game["day"]

        # имя файла: day_1.jpg, day_2.jpg и т.д.
        image_name = f"day_{day_number}.jpg"

        img_path = os.path.join(
            os.path.dirname(__file__),
            "..",
            "day_images",  # папка с картинками
            image_name,
        )

        if os.path.exists(img_path):
            photo = FSInputFile(img_path)
            await message.answer_photo(photo=photo, caption=day_text, parse_mode="HTML")
        else:
            # если картинки нет — просто текст
            await message.answer(day_text, parse_mode="HTML")

    # Случайное событие
    triggered = await maybe_trigger_event(message, game)
    if triggered:
        return

    status = format_status(game)
    warnings = get_warnings(game)
    warn_block = f"\n{warnings}\n" if warnings else ""

    keyboard = get_choices_keyboard(scenario, game["question_index"])
    await message.answer(
        f"{status}{warn_block}\n{scenario.text}",
        reply_markup=keyboard,
        parse_mode="HTML",
    )


@router.callback_query(F.data.startswith("choice:"))
async def choice_handler(callback: CallbackQuery):
    _, question_index, choice_index = callback.data.split(":")
    question_index = int(question_index)
    choice_index = int(choice_index)

    game = await GameRepository.get_game(callback.from_user.id)
    if not game:
        await callback.answer("Игра не найдена. Начни новую!", show_alert=True)
        return

    scenario = ScenarioEngine.get_current(game)
    if not scenario:
        await callback.answer()
        return

    choice = scenario.choices[choice_index]
    desc = getattr(choice, "description", "") or choice.text
    await callback.answer(f"✓ {desc}")

    # Снимаем снэпшот характеристик ДО действия
    before = _snap_stats(game)

    await choice.action(game)
    # ── проверка банкротства ──
    if game.get("money", 0) <= 0:
        await GameEngine._kill(game, "money")
        await finish_game(callback.message, game)
        return

    if game.get("is_dead"):
        await finish_game(callback.message, game)
        return

    # Формируем дельта-сообщение
    after = _snap_stats(game)
    delta_text = format_stat_delta(choice.text, before, after, game)
    if delta_text:
        await callback.message.answer(delta_text, parse_mode="HTML")

    game["question_index"] += 1
    await GameRepository.update_game(
        game["game_id"],
        {
            "question_index": game["question_index"],
            "personality": game["personality"],
            "debt": game.get("debt", 0),
        },
    )

    await send_current_scenario(callback.message, game)


def _snap_stats(game: dict) -> dict:
    """Снимок состояния для вычисления дельты."""
    return {
        "money": game.get("money", 0),
        "health": game["stats"].get("health", 100),
        "hunger": game["stats"].get("hunger", 100),
        "happiness": game["stats"].get("happiness", 100),
        "goal": game["goal"].get("current", 0),
        "debt": game.get("debt", 0),
    }


async def finish_game(message: Message, game: dict):
    from services.personality_engine import PersonalityEngine
    from database.repositories import StatisticsRepository
    from services.endings import determine_ending, format_ending

    ending = determine_ending(game)
    _, ai_analysis = await PersonalityEngine.get_full_analysis(game)

    # ── GAME OVER текст ──
    game_over_block = ""
    if game.get("is_dead"):
        game_over_block = (
            "💀 <b>GAME OVER</b>\n" "Ваше приключение завершилось досрочно.\n\n"
        )

    status = format_status(game)
    ending_text = format_ending(ending, game)

    # завершаем игру
    await GameEngine.finish(game, ending.title)

    # сохраняем статистику
    await StatisticsRepository.save(
        game,
        f"{ending.emoji} {ending.title}",
        ai_report=ai_analysis,
    )

    # ── получаем сохранённую статистику ──
    stats = await StatisticsRepository.get_by_game_id(game["game_id"])

    # защита
    if not stats:
        await message.answer("Игра завершена.")
        return

    # ===== ФОРМИРУЕМ СТАТИСТИКУ (как в statistics.py) =====

    date = stats.get("created_at")
    date_str = date.strftime("%d.%m.%Y %H:%M") if date else "—"

    goal_ok = "✅ Да" if stats.get("goal_completed") else "❌ Нет"
    death = "💀 Да" if stats.get("is_dead") else "✅ Нет"

    p = stats.get("personality", {})
    personality_lines = (
        f"💸 Транжира: {p.get('spender', 0)}\n"
        f"🐷 Накопитель: {p.get('saver', 0)}\n"
        f"📈 Инвестор: {p.get('investor', 0)}\n"
        f"🎲 Рискованный: {p.get('risky', 0)}"
    )

    final_stats = stats.get("final_stats", {})
    stats_lines = (
        f"❤️ Здоровье: {final_stats.get('health', '?')}\n"
        f"🍔 Голод: {final_stats.get('hunger', '?')}\n"
        f"😊 Счастье: {final_stats.get('happiness', '?')}"
    )

    # ===== ИТОГОВЫЙ ТЕКСТ =====

    full_text = (
        f"{game_over_block}"
        f"{status}"
        f"{ending_text}\n\n"
        f"🤖 <b>Анализ ИИ:</b>\n{ai_analysis}\n\n"
        f"📊 <b>Итоговая статистика</b>\n"
        f"📅 {date_str}\n\n"
        f"🧠 <b>Тип: {stats.get('result_type', '?')}</b>\n"
        f"💰 Деньги: {stats.get('final_money', 0)} ₽\n"
        f"💳 Долг: {stats.get('final_debt', 0)} ₽\n"
        f"📅 Дней пройдено: {stats.get('days_completed', 0)}\n"
        f"🎯 Цель достигнута: {goal_ok}\n"
        f"💀 Погиб: {death}\n\n"
        f"<b>📈 Профиль поведения:</b>\n{personality_lines}\n\n"
        f"<b>❤️ Финальные характеристики:</b>\n{stats_lines}"
    )

    from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

    keyboard = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="📋 Мои результаты", callback_data="menu:results"
                )
            ],
            [
                InlineKeyboardButton(
                    text="🔄 Сыграть снова", callback_data="game:restart"
                )
            ],
            [InlineKeyboardButton(text="🏠 Главное меню", callback_data="menu:back")],
        ]
    )

    await message.answer(full_text, parse_mode="HTML", reply_markup=keyboard)
