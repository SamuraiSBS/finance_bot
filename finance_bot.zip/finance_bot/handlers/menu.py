from aiogram import Router, F
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from database.repositories import StatisticsRepository, GameRepository

router = Router()


def main_menu_keyboard(has_results: bool = False):
    buttons = [
        [InlineKeyboardButton(text="🎮 Начать игру", callback_data="menu:play")],
    ]
    if has_results:
        buttons.append(
            [InlineKeyboardButton(text="📋 Мои результаты", callback_data="menu:results")]
        )
    buttons.append([InlineKeyboardButton(text="ℹ️ О игре", callback_data="menu:about")])
    return InlineKeyboardMarkup(inline_keyboard=buttons)


@router.message(F.text == "/start")
async def menu_handler(message: Message):
    stats = await StatisticsRepository.get_user_statistics(message.from_user.id)
    await message.answer(
        "👋 Добро пожаловать в <b>ФинансоГерой</b>!\n\n"
        "🎮 Симулятор финансовой жизни подростка.\n"
        "7 дней — десятки решений — один финансовый портрет.\n\n"
        "Учись управлять деньгами, избегай мошенников, "
        "инвестируй и достигай своих целей!",
        parse_mode="HTML",
        reply_markup=main_menu_keyboard(bool(stats)),
    )


# ── Кнопка «Начать игру» — проверяем есть ли активная игра ──────────────────

@router.callback_query(F.data == "menu:play")
async def menu_play(callback: CallbackQuery):
    await callback.answer()
    uid = callback.from_user.id
    existing = await GameRepository.get_game(uid)

    if existing:
        # Есть незавершённая игра — спрашиваем
        from utils.formatters import format_status
        status = format_status(existing)
        keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(
                text=f"▶️ Продолжить (день {existing['day']}, вопрос {existing['question_index'] + 1})",
                callback_data="game:continue"
            )],
            [InlineKeyboardButton(text="🔄 Начать новую игру", callback_data="game:confirm_new")],
        ])
        await callback.message.answer(
            f"{status}⚠️ У тебя есть незавершённая игра.\n\n"
            "Продолжить с того места или начать заново?",
            parse_mode="HTML",
            reply_markup=keyboard,
        )
    else:
        from handlers.game import start_game_handler
        await start_game_handler(callback.message, uid)


@router.callback_query(F.data == "menu:about")
async def menu_about(callback: CallbackQuery):
    await callback.answer()
    await callback.message.answer(
        "📖 <b>О игре</b>\n\n"
        "Ты проживаешь 7 дней финансовой жизни подростка.\n"
        "Каждый день — новые ситуации:\n\n"
        "• 💰 Тратить или копить?\n"
        "• 📈 Рискнуть или сохранить?\n"
        "• 🚨 Распознать мошенника?\n"
        "• 💳 Брать кредит или копить самому?\n\n"
        "В конце ИИ-аналитик составит твой финансовый портрет!\n\n"
        "🎯 Характеристики:\n"
        "❤️ Здоровье | 🍔 Сытость | 😊 Счастье | 💰 Деньги",
        parse_mode="HTML",
    )


@router.callback_query(F.data == "menu:results")
async def menu_results(callback: CallbackQuery):
    await callback.answer()
    await show_results_list(callback.message, callback.from_user.id)


async def show_results_list(message: Message, user_id: int):
    stats = await StatisticsRepository.get_user_statistics(user_id)
    if not stats:
        await message.answer("У тебя пока нет завершённых игр. Сыграй первую! 🎮")
        return

    buttons = []
    for i, game in enumerate(stats):
        date = game.get("created_at")
        date_str = date.strftime("%d.%m %H:%M") if date else f"Игра {i + 1}"
        label = f"🎮 {date_str} — {game.get('result_type', '?')}"
        buttons.append([
            InlineKeyboardButton(text=label, callback_data=f"stat:{game['game_id']}")
        ])
    buttons.append([InlineKeyboardButton(text="🏠 Главное меню", callback_data="menu:back")])

    await message.answer(
        "📋 <b>Твои прохождения:</b>",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=buttons),
    )


@router.callback_query(F.data == "menu:back")
async def menu_back(callback: CallbackQuery):
    await callback.answer()
    stats = await StatisticsRepository.get_user_statistics(callback.from_user.id)
    await callback.message.answer(
        "🏠 Главное меню",
        reply_markup=main_menu_keyboard(bool(stats)),
    )
