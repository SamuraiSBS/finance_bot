from aiogram import Router, F
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.filters import Command

from config import config
from database.repositories import GameRepository, StatisticsRepository

router = Router()


def is_admin(user_id: int) -> bool:
    return user_id == config.ADMIN_ID


# ── /admin — главное меню ────────────────────────────────────────────────────

@router.message(Command("admin"))
async def admin_panel(message: Message):
    if not is_admin(message.from_user.id):
        await message.answer("⛔ Нет доступа.")
        return

    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🗑️ Сбросить свою игру", callback_data="adm:reset_self")],
        [InlineKeyboardButton(text="🔍 Сбросить игру пользователя", callback_data="adm:reset_user")],
        [InlineKeyboardButton(text="📊 Статистика всех игр", callback_data="adm:stats_all")],
        [InlineKeyboardButton(text="👥 Кол-во пользователей", callback_data="adm:user_count")],
    ])
    await message.answer(
        "🛠 <b>Админ-панель</b>\n\nВыбери действие:",
        parse_mode="HTML",
        reply_markup=keyboard,
    )


# ── Сбросить свою игру ───────────────────────────────────────────────────────

@router.callback_query(F.data == "adm:reset_self")
async def admin_reset_self(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        await callback.answer("⛔ Нет доступа.", show_alert=True)
        return

    await GameRepository.delete_active_game(callback.from_user.id)
    await callback.answer("✅ Твоя текущая игра сброшена.", show_alert=True)
    await callback.message.answer(
        "✅ Игра сброшена. Нажми «🎮 Начать игру» для новой партии.",
    )


# ── Сбросить игру пользователя — ввод ID ────────────────────────────────────

WAITING_FOR_USER_ID: set[int] = set()


@router.callback_query(F.data == "adm:reset_user")
async def admin_reset_user_prompt(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        await callback.answer("⛔ Нет доступа.", show_alert=True)
        return

    WAITING_FOR_USER_ID.add(callback.from_user.id)
    await callback.answer()
    await callback.message.answer(
        "✏️ Введи <b>Telegram user_id</b> пользователя, чью игру нужно сбросить:",
        parse_mode="HTML",
    )


@router.message(F.text.regexp(r"^\d+$"))
async def admin_reset_user_execute(message: Message):
    if not is_admin(message.from_user.id):
        return
    if message.from_user.id not in WAITING_FOR_USER_ID:
        return

    WAITING_FOR_USER_ID.discard(message.from_user.id)
    target_id = int(message.text)
    game = await GameRepository.get_game(target_id)

    if not game:
        await message.answer(f"ℹ️ У пользователя {target_id} нет активной игры.")
        return

    await GameRepository.delete_active_game(target_id)
    await message.answer(
        f"✅ Игра пользователя <code>{target_id}</code> (день {game['day']}, "
        f"вопрос {game['question_index']}) — сброшена.",
        parse_mode="HTML",
    )


# ── Статистика всех игр ──────────────────────────────────────────────────────

@router.callback_query(F.data == "adm:stats_all")
async def admin_stats_all(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        await callback.answer("⛔ Нет доступа.", show_alert=True)
        return

    await callback.answer()
    cursor = StatisticsRepository.get_collection().find({})
    all_stats = await cursor.to_list(length=1000)

    if not all_stats:
        await callback.message.answer("📊 Завершённых игр пока нет.")
        return

    total = len(all_stats)
    endings: dict[str, int] = {}
    for s in all_stats:
        key = s.get("result_type", "?")
        endings[key] = endings.get(key, 0) + 1

    lines = [f"📊 <b>Статистика всех игр:</b>\n", f"Всего завершено: <b>{total}</b>\n"]
    for ending_type, count in sorted(endings.items(), key=lambda x: -x[1]):
        lines.append(f"  {ending_type}: {count}")

    await callback.message.answer("\n".join(lines), parse_mode="HTML")


# ── Количество уникальных пользователей ──────────────────────────────────────

@router.callback_query(F.data == "adm:user_count")
async def admin_user_count(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        await callback.answer("⛔ Нет доступа.", show_alert=True)
        return

    await callback.answer()
    all_ids = await StatisticsRepository.get_collection().distinct("user_id")
    active_cursor = GameRepository.get_collection().find({"is_finished": False})
    active = await active_cursor.to_list(length=1000)

    await callback.message.answer(
        f"👥 <b>Пользователи:</b>\n"
        f"Уникальных (играли): <b>{len(all_ids)}</b>\n"
        f"Сейчас в игре: <b>{len(active)}</b>",
        parse_mode="HTML",
    )
