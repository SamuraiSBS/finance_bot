from dataclasses import dataclass, asdict
import uuid
import random


GOALS = [
    ("Велосипед", 5000),
    ("Смартфон", 10000),
    ("Игровая приставка", 15000),
    ("Ноутбук", 25000),
    ("Беспроводные наушники", 7000),
    ("Электросамокат", 20000),
]


@dataclass
class Stats:
    happiness: int = 100
    health: int = 100
    hunger: int = 100


@dataclass
class Goal:
    name: str
    target: int
    current: int = 0


@dataclass
class Personality:
    spender: int = 0
    saver: int = 0
    investor: int = 0
    risky: int = 0


@dataclass
class GameState:
    game_id: str
    user_id: int

    day: int = 1
    question_index: int = 0
    money: int = 1000
    debt: int = 0

    stats: dict = None
    goal: dict = None
    personality: dict = None
    history: list = None

    is_finished: bool = False
    is_dead: bool = False

    @staticmethod
    def create(user_id: int):
        goal_name, goal_amount = random.choice(GOALS)
        return GameState(
            game_id=str(uuid.uuid4()),
            user_id=user_id,
            stats=Stats().__dict__,
            goal=Goal(goal_name, goal_amount).__dict__,
            personality=Personality().__dict__,
            history=[],
        )

    def to_dict(self):
        return asdict(self)
