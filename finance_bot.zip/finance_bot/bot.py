import asyncio
from aiogram import Bot, Dispatcher
from aiogram.fsm.storage.memory import MemoryStorage
from config import config
from database.mongo import Mongo
from handlers import game, menu, statistics, ai, events, admin


bot = Bot(token=config.BOT_TOKEN)
dp = Dispatcher(storage=MemoryStorage())


async def main():
    await Mongo.connect()
    print("✅ Mongo connected")

    dp.include_router(admin.router)  # первым — чтобы /admin не перехватывался
    dp.include_router(menu.router)
    dp.include_router(game.router)
    dp.include_router(statistics.router)
    dp.include_router(ai.router)
    dp.include_router(events.router)

    print("🚀 Bot started")
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
