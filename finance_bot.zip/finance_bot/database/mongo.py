from motor.motor_asyncio import AsyncIOMotorClient
from config import config


class Mongo:

    client: AsyncIOMotorClient = None
    db = None

    @classmethod
    async def connect(cls):
        cls.client = AsyncIOMotorClient(config.MONGO_URI)
        cls.db = cls.client[config.DB_NAME]

    @classmethod
    def get_db(cls):
        return cls.db
