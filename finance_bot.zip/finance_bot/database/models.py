class User:

    def __init__(self, user_id, money):

        self.user_id = user_id
        self.money = money
        self.spent = 0
        self.day = 0