from database.mongo import Mongo
from models.game_state import GameState
from datetime import datetime


class GameRepository:

    collection = None

    @classmethod
    def get_collection(cls):
        if cls.collection is None:
            cls.collection = Mongo.get_db()["active_games"]
        return cls.collection

    @classmethod
    async def create_game(cls, game: GameState):
        await cls.get_collection().insert_one(game.to_dict())

    @classmethod
    async def get_game(cls, user_id: int):
        return await cls.get_collection().find_one(
            {"user_id": user_id, "is_finished": False}
        )

    @classmethod
    async def update_game(cls, game_id: str, data: dict):
        await cls.get_collection().update_one({"game_id": game_id}, {"$set": data})

    @classmethod
    async def finish_game(cls, game_id: str):
        await cls.get_collection().update_one(
            {"game_id": game_id}, {"$set": {"is_finished": True}}
        )

    @classmethod
    async def delete_active_game(cls, user_id: int):
        """Удаляет активную игру (для рестарта)."""
        await cls.get_collection().delete_one({"user_id": user_id, "is_finished": False})


class StatisticsRepository:

    collection = None

    @classmethod
    def get_collection(cls):
        if cls.collection is None:
            cls.collection = Mongo.get_db()["statistics"]
        return cls.collection

    @classmethod
    async def save(cls, game: dict, result_type: str, ai_report: str = ""):
        doc = {
            "game_id": game["game_id"],
            "user_id": game["user_id"],
            "result_type": result_type,
            "final_money": game["money"],
            "final_debt": game.get("debt", 0),
            "goal_completed": game["goal"]["current"] >= game["goal"]["target"],
            "goal_name": game["goal"]["name"],
            "goal_progress": game["goal"]["current"],
            "goal_target": game["goal"]["target"],
            "days_completed": game["day"],
            "is_dead": game.get("is_dead", False),
            "personality": game.get("personality", {}),
            "final_stats": game.get("stats", {}),
            "ai_report": ai_report,
            "created_at": datetime.utcnow(),
        }
        await cls.get_collection().insert_one(doc)

    @classmethod
    async def get_user_statistics(cls, user_id: int):
        cursor = cls.get_collection().find(
            {"user_id": user_id},
            sort=[("created_at", -1)]
        )
        return await cursor.to_list(length=50)

    @classmethod
    async def get_by_game_id(cls, game_id: str):
        return await cls.get_collection().find_one({"game_id": game_id})
